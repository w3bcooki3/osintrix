# Changelog

All notable changes to OSINTrix, newest first. The format is based on [Keep a Changelog](https://keepachangelog.com); this file is generated from `js/data/changelog.js` by `tools/changelog.py`.

## [1.83] — Case templates (2026-11-25)

_Start a case already set up for the kind of work it is._

### Added
- New case now starts from a template: Story, Person, Company due diligence, Phishing, Incident, Fraud or scam, Threat actor or Missing person, or Blank. Each brings its own questions, the matching playbooks' steps as open questions, a scope hint, an icon and colour, and opens on the right tab (Story, Graph, Map…).
- Before creating, untick any playbook or question you don't want.
- Save any case as your own template from the case menu. Only the structure is kept (questions, playbooks, scope, look and starting tab), never evidence, entries or answers. Your templates sit above the built-in ones and can be deleted.

### Changed
- Quick new case from Capture still goes straight to the form.

## [1.82] — SSH keys and decentralised accounts (2026-11-25)

_Two new kinds of identifier that tie servers and people together._

### Added
- SSH keys are found in authorized_keys, known_hosts, auth logs, ssh -v output and Shodan or Censys results. Every form is named by its SHA-256 fingerprint, so a pasted key, a fingerprint in a log and a scanner hit are one key. The details show its type and size, weak or outdated keys, the comment it was made with, and every machine it was seen on.
- Fediverse (@user@server), Matrix (@user:server), Nostr (npub, nprofile and signed events) and Bluesky IDs (did:plc, did:web) are found and checked, with profile links, the PLC directory's handle history, and a note when an account lives on a small or personal server.
- A Nostr private key (nsec) in evidence is flagged as a leaked secret and never kept.
- These count as strong identifiers for personas, and one name across the fediverse, Matrix and other networks shows under Related in the duplicate finder.

## [1.81] — Damaged files (2026-11-25)

_Hostile and broken files are read as far as they can be._

### Fixed
- In the Lab, a damaged part of a file no longer hides the rest. The part that could not be read is named, and hashes, strings and everything else are still shown.
- A cut-off Windows shortcut (.lnk) could stop the file from being read at all. It now shows what is left, including the target.

## [1.80] — For reporting (2026-11-25)

_A Story tab on every case, for journalists._

### Added
- Claims: each thing the story says as fact, with evidence for and against it and who it is about. “Before you publish” lists what is not ready: fewer than two independent sources, unverified pictures, no right of reply, cited pages with no archived copy.
- Protected sources: a person kept under a pseudonym, their real details encrypted with a passphrase of their own and shown only when you ask. They lock after ten idle minutes or when you leave the tab. Burning a source wipes it from the workspace and from every restore point.
- Right of reply: who was asked to comment, how, the deadline and what they said. Deadlines coming up show on Today.
- Archived pages: save each cited page to the Wayback Machine in one click, and keep the link to the copy.

## [1.79] — Vehicles, ships and aircraft (2026-11-25)

_New identifiers, a lighter offline file, and related entries found for you._

### Added
- VINs, IMO numbers, MMSIs, aircraft registrations and ICAO addresses are found in evidence. Each is checked and read offline: maker and year from a VIN, flag from an MMSI, and a US registration and its address worked out from each other.
- Vehicle, ship and aircraft entries in the vault, with lookup links (NHTSA, MarineTraffic, ADS-B Exchange, FAA registry).
- Duplicates finds the same ship or aircraft under different numbers. A new Related tab offers links for one name on several accounts and for look-alike domains, with the reason on each link.

### Changed
- The one-file copy is a quarter smaller and opens faster: big data files are packed and unpacked only when needed.

## [1.78] — URLs keep their case, one Patterns page (2026-11-25)

_Small fixes from daily use._

### Added
- The Decoder, Certificates and Cloud guide keep your recent input too, if tool history is on in Settings.
- More save buttons have the ▾ to pick any case or make a new one.
- If something on a page fails, a notice says so and has a “Copy details” button for bug reports.

### Changed
- URLs keep the case of their path and query, so share links and tokens still work when opened. Only the scheme and host are lowercased. URLs saved earlier get their case back from the record they came from.
- Patterns: the regex builder and the log parsers are now one page with two tabs.

### Fixed
- The graph could stop responding to the mouse after adding from evidence, until you clicked elsewhere. It now keeps working.

## [1.77] — Save to any case (2026-11-24)

_Pick where things go, and clear tools in one click._

### Added
- The ▾ beside a save button lists every case and “New case…”.
- Investigate and Decode tools have Clear. They can also keep your last 10 searches, which is off by default.

### Changed
- Look-alikes lists candidates at once. Page hash shows what a saved page loads and where it sends data. Hashes decodes what can be decoded.

### Fixed
- Layout fixes in Entities and Settings.

## [1.76] — WinForensicX hand-off (2026-11-24)

_Move indicators between OSINTrix and WinForensicX._

### Added
- Import the STIX file that WinForensicX exports. You can add its indicators to a case as well.
- Export a hunt list that Invoke-WfxHunt -IocFile reads.

### Fixed
- A file entry with an MD5 or SHA-1 is filed as that hash, so it joins the same hash found in records.

## [1.60–1.75] — Forensics kit and tradecraft (2026-11-24)

_Tools for the files and accounts an investigation turns up._

### Added
- Forensics kit: documents, web captures, browser profiles, stealer logs, phishing kits, chat exports. Each is read and summarised.
- Wallet trails, now with Solana, from pasted text or files.
- Personas with an OPSEC check and a log, plus onion pages and Web3 identifiers.
- Linked notebook, note reminders, and cases kept in files.

### Changed
- A design pass across every screen.

## [1.40–1.59] — Reading evidence like an analyst (2026-11-23)

_Better reading of indicators and logs, and room for big cases._

### Added
- Regex builder, plus masking for anything you share.
- Endpoint evidence, certificates, cloud logs and detection rules, each checked against your cases.
- Case snapshots, saved views and @ links in notes.

### Changed
- Large vaults and graphs stay workable.

## [1.12–1.39] — Cases, intel and the engine (2026-11-15)

_The core of the workspace._

### Added
- Threat Intel feeds, the investigation engine, Copilot and graph analysis.
- Certificates, Cloud, the Notebook, media in cases and the detection lab.

### Changed
- A new design and a cases board.

### Fixed
- Hardened storage and a faster start, so nothing is lost on reload or when space runs low.

## [0.x–1.11] — The beginning (2026-10-08)

_ThreatNet and Clew merged into one offline workspace._

### Added
- Toolbox, timeline-based cases, entity extraction, the graph and the map.
- Playbooks, pivots, exports, the Lab and a CTF area.
- Search across everything, chain of custody and a safety net for your data.

---

_Generated 2026-11-25 from `js/data/changelog.js`. Do not edit this file by hand — edit the data file and run `python tools/changelog.py`._
