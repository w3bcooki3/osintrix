/* ==========================================================================
   Toolbox (the Intelligence Vault), Entities, Feeds, Decoder, Reference,
   Settings, and honest placeholders for modules not yet migrated.
   ========================================================================== */
const CAT_COL = {osint:'#8b5cf6', 'digital-forensics':'#0ea5a4', 'malware-analysis':'#e5484d', 'network-security':'#3b82f6', 'threat-intelligence':'#f59e0b', 'incident-response':'#f97316', 'ai-automation':'#ec4899', compliance:'#64748b', general:'#5468ff'};
const catCol = c => CAT_COL[c] || '#5468ff';
const BADGE_HUES = ['#6366f1','#0ea5a4','#e5484d','#f59e0b','#8b5cf6','#3b82f6','#ec4899','#10b981','#f97316','#06b6d4'];
const badgeCol = s => { let h = 0; for(const c of String(s)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return BADGE_HUES[h % BADGE_HUES.length]; };
const mono = (t, cls = '') => `<span class="tbadge ${cls}" style="--cc:${badgeCol(t.name)}" aria-hidden="true">${esc((t.name.match(/[A-Za-z0-9]/) || ['?'])[0].toUpperCase())}</span>`;
const toolSub = t => { const cat = TOOL_CATS[t.cat] || {name:t.cat, children:{}}; return cat.children[t.sub] || cat.name; };
/* ---------- Toolbox: one library, four ways to look at it ----------
   List (with a details panel), Table (sortable, bulk actions), Cards, Compact A–Z. */
const tmono = (t, s = 32) => { const w = String(t.name).match(/[A-Za-z0-9]+/g) || ['?']; const m = w.length > 1 ? (w[0][0] + w[1][0]).toUpperCase().replace(/^(.)(.)$/, (x, a, b) => a + b.toLowerCase()) : (w[0][0].toUpperCase() + (w[0][1] || '').toLowerCase());
  return `<span class="tmo" style="--cc:${catCol(t.cat)};--s:${s}px" aria-hidden="true">${esc(m)}</span>`; };
const tLink = (t, inner, cls = '') => { const u = E.safeUrl(t.url); return u ? `<a class="${cls}" href="${esc(u)}" target="_blank" rel="noopener noreferrer" data-act="toolOpen" data-id="${t.id}">${inner}</a>` : `<span class="${cls}">${inner}</span>`; };
const tStar = (t, cls = 'tb-ic') => `<button class="${cls}${t.starred ? ' on star' : ''}" data-act="toolStar" data-id="${t.id}" aria-label="${t.starred ? 'Remove from favourites' : 'Add to favourites'}" title="Favourite">${ico('star','sm')}</button>`;
const tGo = t => { const u = E.safeUrl(t.url); return u ? `<a class="tb-ic" href="${esc(u)}" target="_blank" rel="noopener noreferrer" data-act="toolOpen" data-id="${t.id}" aria-label="Open ${esc(t.name)} in a new tab" title="Open">${ico('arrow-up-right','sm')}</a>` : ''; };
const tAgo = t => t.last ? esc(E.fmtAgo(Math.max(0, Date.now() - t.last))) : '—';
const tPick = t => `<label class="tpk"><span class="sr">Select ${esc(t.name)}</span><input type="checkbox" data-act="toolPick" data-id="${t.id}"${UI.tpick && UI.tpick.has(t.id) ? ' checked' : ''}></label>`;
function paintBulk(){
  const el = $('tbk'); if(!el) return; const n = UI.tpick ? [...UI.tpick].filter(id => DB.tools.some(t => t.id === id)).length : 0;
  el.hidden = !n; document.querySelectorAll('.tbx2').forEach(x => x.classList.toggle('picking', !!n)); if(!n) return;
  el.innerHTML = `<b>${n} selected</b><button class="btn xs" data-act="bulkAll">Select all shown</button><span class="sep"></span>
    <button class="btn xs" data-act="bulkStar">${ico('star','sm')}Favourite</button><button class="btn xs" data-act="bulkPin">${ico('pin','sm')}Quick launch</button><button class="btn xs" data-act="bulkExport">${ico('download','sm')}Export</button>
    <button class="btn xs rd" data-act="bulkDel">${ico('trash-2','sm')}Delete</button><button class="iconbtn" data-act="bulkClear" aria-label="Clear selection">${ico('x','sm')}</button>`;
}
function tRow(t){
  return `<div class="tr2-r${UI.tsel === t.id ? ' on' : ''}" data-id="${t.id}" data-pick="${t.id}"><button class="gcard-hit" data-act="toolSel" data-id="${t.id}" aria-label="${esc(t.name)} — show details"></button>
    ${tPick(t)}<div class="tr2-n">${tmono(t, 32)}<div><b>${esc(t.name)}</b><small>${esc(hostOf(t.url))}</small></div></div>
    <p class="tr2-d">${esc(t.desc || '')}</p>
    <span class="tr2-c"><i class="cdot" style="background:${catCol(t.cat)}"></i>${esc(toolSub(t))}</span>
    <span class="tr2-u" title="Last opened">${t.last ? tAgo(t) : ''}</span>
    <span class="tr2-a">${t.tpl ? `<button class="tb-ic run" data-act="toolRun" data-id="${t.id}" aria-label="Look something up with ${esc(t.name)}" title="Look up a value">${ico('play','sm')}</button>` : ''}${tStar(t)}${tGo(t)}</span></div>`;
}
function tCard(t){
  return `<article class="tcd-c${UI.tpick && UI.tpick.has(t.id) ? ' picked' : ''}" data-pick="${t.id}">
    <header>${tmono(t, 40)}${tPick(t)}${tStar(t, 'tb-ic tcd-s')}</header>
    <h3>${tLink(t, esc(t.name))}</h3><span class="tcd-h">${esc(hostOf(t.url))}</span>
    <p>${esc(t.desc || 'No description yet.')}</p>
    ${t.tags.length ? `<div class="tcd-t">${t.tags.slice(0, 3).map(g => `<button data-act="toolTag" data-v="${esc(g)}" title="Show tools tagged ${esc(g)}">${esc(g.replace(/-/g, ' '))}</button>`).join('')}</div>` : ''}
    <footer><span class="tr2-c"><i class="cdot" style="background:${catCol(t.cat)}"></i>${esc(toolSub(t))}</span><span class="sp"></span>
      ${t.tpl ? `<button class="tb-ic run" data-act="toolRun" data-id="${t.id}" aria-label="Look something up with ${esc(t.name)}" title="Look up a value">${ico('play','sm')}</button>` : ''}
      <button class="tb-ic" data-act="toolMenu" data-id="${t.id}" aria-label="More actions for ${esc(t.name)}" title="More">${ico('ellipsis','sm')}</button>
      ${tLink(t, 'Open' + ico('arrow-up-right','sm'), 'tcd-o')}</footer></article>`;
}
function tTable(list, sort){
  const th = (k, l, cls = '') => `<th class="${cls}"><button class="th-s" data-act="tsortBy" data-v="${k}" aria-pressed="${sort === k}">${l}${sort === k ? ico('chevron-down','sm') : ''}</button></th>`;
  return `<div class="tblwrap tt"><table class="tbl tt-t"><thead><tr><th class="ck"><label class="tpk"><span class="sr">Select all shown</span><input type="checkbox" data-act="bulkAllT"${UI.tpick && list.length && list.every(t => UI.tpick.has(t.id)) ? ' checked' : ''}></label></th>${th('name','Name')}<th class="hide-m">Link</th><th>Category</th><th class="hide-m">Tags</th>${th('recent','Added','hide-m')}${th('last','Last used')}${th('used','Uses','n')}<th></th></tr></thead><tbody>
    ${list.map(t => `<tr class="${UI.tpick && UI.tpick.has(t.id) ? 'sel' : ''}" data-pick="${t.id}"><td class="ck">${tPick(t)}</td>
      <td class="nm"><div>${tmono(t, 26)}${tLink(t, esc(t.name))}${t.seed ? '' : '<span class="tt-cu">Custom</span>'}</div></td>
      <td class="mo hide-m">${esc(hostOf(t.url))}</td><td><span class="tr2-c"><i class="cdot" style="background:${catCol(t.cat)}"></i>${esc(toolSub(t))}</span></td>
      <td class="hide-m"><span class="tt-tg">${t.tags.slice(0, 2).map(g => `<button data-act="toolTag" data-v="${esc(g)}">${esc(g)}</button>`).join('')}</span></td>
      <td class="mo hide-m">${t.added ? esc(new Date(t.added).toISOString().slice(0, 10)) : '—'}</td><td class="mo">${tAgo(t)}</td><td class="n">${t.uses || '—'}</td>
      <td class="ac">${tStar(t)}<button class="tb-ic" data-act="toolMenu" data-id="${t.id}" aria-label="More actions for ${esc(t.name)}" title="More">${ico('ellipsis','sm')}</button></td></tr>`).join('')}</tbody></table></div>`;
}
function tCompact(list){
  const by = new Map(); list.forEach(t => { const k = /[a-z]/i.test(t.name[0]) ? t.name[0].toUpperCase() : '#'; if(!by.has(k)) by.set(k, []); by.get(k).push(t); });
  const keys = [...by.keys()].sort((a, b) => a === '#' ? -1 : b === '#' ? 1 : a.localeCompare(b));
  return `<div class="tcx">${keys.map(k => `<section><h3>${k}</h3>${by.get(k).map(t => tLink(t, `${tmono(t, 20)}<span>${esc(t.name)}</span>${t.starred ? `<i class="st">${ico('star','sm')}</i>` : ''}`, 'tcx-a')).join('')}</section>`).join('')}</div>`;
}
function tDetail(t){
  if(!t) return '';
  const u = E.safeUrl(t.url);
  return `<aside class="tdet" aria-label="${esc(t.name)} details"><div class="tdet-h">${tmono(t, 46)}<div><h2>${esc(t.name)}</h2><span class="mono">${esc(hostOf(t.url))}</span></div><button class="iconbtn" data-act="toolSelX" aria-label="Close details">${ico('x','sm')}</button></div>
    <div class="tdet-a">${u ? `<a class="btn primary" href="${esc(u)}" target="_blank" rel="noopener noreferrer" data-act="toolOpen" data-id="${t.id}">${ico('arrow-up-right','sm')}Open</a>` : ''}<button class="btn" data-act="toolCopy" data-id="${t.id}">${ico('copy','sm')}Copy link</button><button class="btn" data-act="toolEdit" data-id="${t.id}">${ico('pencil','sm')}Edit</button></div>
    <p>${esc(t.desc || 'No description yet.')}</p>
    ${t.tpl ? `<form class="tdet-q" data-form="toolRun" data-id="${t.id}"><label class="ix" for="tdV">Look up with ${esc(t.name)}</label><div class="r"><input id="tdV" class="inp mono" placeholder="Value — IP, domain, email, hash…" autocomplete="off"><button class="btn">Go</button></div><code>${esc(t.tpl)}</code></form>` : ''}
    <dl class="tdet-kv"><dt>Category</dt><dd class="blk"><i class="cdot" style="background:${catCol(t.cat)}"></i>${esc((TOOL_CATS[t.cat] || {name:t.cat}).name)} · ${esc(toolSub(t))}</dd>
      ${t.tags.length ? `<dt>Tags</dt><dd>${t.tags.map(g => `<button class="tag" data-act="toolTag" data-v="${esc(g)}">${esc(g)}</button>`).join('')}</dd>` : ''}
      <dt>Opened</dt><dd>${t.uses ? `${t.uses} time${t.uses > 1 ? 's' : ''}${t.last ? ' · last ' + tAgo(t) : ''}` : 'Not yet'}</dd>
      <dt>Added</dt><dd>${t.added ? esc(new Date(t.added).toISOString().slice(0, 10)) : '—'}${t.seed ? ' · pre-added' : ' · by you'}</dd></dl>
    <div class="tdet-f"><button class="btn sm${t.starred ? ' on' : ''}" data-act="toolStar" data-id="${t.id}">${ico('star','sm')}${t.starred ? 'Favourite' : 'Add to favourites'}</button><button class="btn sm${t.pinned ? ' on' : ''}" data-act="toolPin" data-id="${t.id}">${ico('pin','sm')}${t.pinned ? 'In quick launch' : 'Quick launch'}</button><span class="sp"></span><button class="btn sm tdel" data-act="toolDelAsk" data-id="${t.id}">${ico('trash-2','sm')}Delete</button></div></aside>`;
}
const TVIEWS = [['list','layout-list','List'],['table','table-2','Table'],['cards','layout-grid','Cards'],['compact','rows-3','Compact']];
const TSETS = [['all','layers','All tools'],['fav','star','Favourites'],['pinned','pin','Quick launch'],['recent','clock','Recently used'],['mine','user','Added by you']];
function viewToolbox(){
  if(UI.tcat === 'fav' || UI.tcat === 'pinned'){ UI.tset = UI.tcat; UI.tcat = 'all'; }
  const set = UI.tset || 'all', q = UI.tq.toLowerCase().trim();
  let view = UI.tview || DB.prefs.tview || 'list'; if(view === 'tiles') view = 'cards'; if(!TVIEWS.some(v => v[0] === view)) view = 'list';
  let sort = UI.tsort || (set === 'recent' ? 'last' : 'name');
  const inSet = t => set === 'fav' ? t.starred : set === 'pinned' ? t.pinned : set === 'recent' ? !!t.last : set === 'mine' ? !t.seed : true;
  const setN = k => DB.tools.filter(t => k === 'fav' ? t.starred : k === 'pinned' ? t.pinned : k === 'recent' ? !!t.last : k === 'mine' ? !t.seed : true).length;
  const base = DB.tools.filter(inSet), cnt = c => base.filter(t => t.cat === c).length;
  const cats = Object.entries(TOOL_CATS).filter(([k]) => k !== 'general' && DB.tools.some(t => t.cat === k));
  if(UI.tcat !== 'all' && !TOOL_CATS[UI.tcat]) UI.tcat = 'all';
  let list = base.filter(t => (UI.tcat === 'all' || (t.cat === UI.tcat && (!UI.tsub || t.sub === UI.tsub))) && (!q || (t.name + ' ' + t.desc + ' ' + t.tags.join(' ') + ' ' + hostOf(t.url)).toLowerCase().includes(q)));
  const byName = (a, b) => a.name.localeCompare(b.name, undefined, {sensitivity:'base'});
  list.sort(sort === 'recent' ? (a, b) => (b.added || 0) - (a.added || 0) : sort === 'used' ? (a, b) => (b.uses || 0) - (a.uses || 0) || byName(a, b) : sort === 'last' ? (a, b) => (b.last || 0) - (a.last || 0) || byName(a, b) : byName);
  const sel = view === 'list' ? DB.tools.find(t => t.id === UI.tsel) : null;
  const subs = UI.tcat !== 'all' ? Object.entries(TOOL_CATS[UI.tcat].children).filter(([sb]) => base.some(t => t.cat === UI.tcat && t.sub === sb)) : [];
  let body;
  if(!list.length) body = empty('wrench', q ? 'No tools match “' + esc(UI.tq) + '”' : 'Nothing here yet', q ? 'Check the spelling, try a tag, or add the tool yourself.' : set === 'fav' ? 'Star a tool to keep it here.' : set === 'pinned' ? 'Pin a tool to add it to quick launch.' : set === 'recent' ? 'Tools you open show up here.' : 'Add a tool or import a list.', `<button class="btn primary" data-act="toolAdd">${ico('plus','sm')}Add tool</button>`);
  else if(view === 'table') body = tTable(list, sort);
  else if(view === 'cards') body = `<div class="tcg">${list.map(tCard).join('')}</div>`;
  else if(view === 'compact') body = tCompact(list);
  else {
    const fav = !q && set === 'all' && sort === 'name' ? list.filter(t => t.starred) : [];
    const rest = fav.length ? list.filter(t => !t.starred) : list;
    body = `<div class="tlst">${fav.length ? `<div class="tr2-g ix">${ico('star','sm')}Favourites<span>${fav.length}</span></div>${fav.map(tRow).join('')}<div class="tr2-g ix">Everything else<span>${rest.length}</span></div>` : ''}${rest.map(tRow).join('')}</div>`;
  }
  const sortL = {name:'Name A–Z', last:'Last used', used:'Most opened', recent:'Recently added'};
  return `<div class="tbx2${sel ? ' has-det' : ''}">
    <header class="tbx2-h"><div class="tbx2-t"><h1>Toolbox</h1><span class="ct">${DB.tools.length}</span></div>
      <div class="search-in tbx2-q">${ico('search')}<label class="sr" for="tq">Search tools</label><input id="tq" class="inp" placeholder="Search tools by name, link or tag" value="${esc(UI.tq)}" autocomplete="off">${UI.tq ? `<button class="iconbtn" data-act="tqClear" aria-label="Clear search">${ico('x','sm')}</button>` : '<kbd>/</kbd>'}</div>
      <div class="tbx2-b"><button class="btn" data-act="toolImport">${ico('upload','sm')}<span>Import</span></button><button class="btn primary" data-act="toolAdd">${ico('plus','sm')}<span>Add tool</span></button></div></header>
    <div class="tbx2-bar"><nav class="tsets" aria-label="Tool lists">${TSETS.map(([k, i, l]) => `<button data-act="tset" data-v="${k}" aria-pressed="${set === k}">${ico(i,'sm')}${l}<small>${setN(k)}</small></button>`).join('')}</nav>
      <div class="tbx2-c"><label class="sr" for="tSort">Sort</label><span class="tsort">${ico('arrow-down-up','sm')}<select id="tSort" class="gsel">${Object.entries(sortL).map(([k, l]) => `<option value="${k}"${sort === k ? ' selected' : ''}>${l}</option>`).join('')}</select></span>
        <div class="seg tvs" role="group" aria-label="View">${TVIEWS.map(([v, i, l]) => `<button data-act="tview" data-v="${v}" aria-pressed="${view === v}" title="${l}" aria-label="${l} view">${ico(i,'sm')}</button>`).join('')}</div></div></div>
    <div class="tchp"><button data-act="tcat" data-v="all" aria-pressed="${UI.tcat === 'all'}">All<small>${base.length}</small></button>${cats.map(([k, c]) => `<button data-act="tcat" data-v="${k}" aria-pressed="${UI.tcat === k}"><i class="cdot" style="background:${catCol(k)}"></i>${esc(c.name.split(' &')[0])}<small>${cnt(k)}</small></button>`).join('')}</div>
    ${subs.length > 1 ? `<div class="tchp sub">${subs.map(([sb, l]) => `<button data-act="tsub" data-v="${sb}" aria-pressed="${UI.tsub === sb}">${esc(l)}<small>${base.filter(t => t.sub === sb).length}</small></button>`).join('')}</div>` : ''}
    <div class="tbk" id="tbk" hidden></div>
    <div class="tbx2-m"><div class="tbx2-l" id="tlist">${list.length && view !== 'compact' ? `<p class="tbx2-n">${list.length === DB.tools.length ? list.length + ' tools' : list.length + ' of ' + DB.tools.length + ' tools'}${q ? ' matching “' + esc(UI.tq) + '”' : ''} · ${sortL[sort].toLowerCase()}</p>` : ''}${body}</div>${sel ? '<div class="tdet-scrim" data-act="toolSelX" aria-hidden="true"></div>' : ''}${tDetail(sel)}</div></div>`;
}
/* layout switcher shared by Toolbox, Query library and Detections */
const layoutSeg = (act, cur, opts) => `<div class="seg lseg" role="group" aria-label="Layout">${opts.map(([v, i, l]) => `<button data-act="${act}" data-v="${v}" aria-pressed="${cur === v}" title="${l} layout">${ico(i,'sm')}<span>${l}</span></button>`).join('')}</div>`;
function viewEntities(){
  const g = [...globalEnts().values()];
  const eq = (UI.entq || '').toLowerCase();
  const ec = UI.entCase && DB.cases.some(c => c.id === UI.entCase) ? UI.entCase : '';
  let list = g.filter(e => (!ec || e.cases.has(ec)) && (!UI.entKind || (UI.entKind === 'malicious' ? verdictOf(e.id) === 'malicious' : UI.entKind === 'cross' ? e.cases.size > 1 : true)) && (!eq || (e.v + ' ' + (E.LABEL[e.k] || e.k)).toLowerCase().includes(eq)));
  UI.entList = list;
  list.sort((a, b) => b.recs.length - a.recs.length);
  return `<div class="scroll"><div class="page">
    <div class="ph"><div><h1>Entities</h1><div class="sub">Every indicator across every case, whether you added it to a vault or it was extracted from evidence. Each case also has its own Entities tab.</div></div></div>
    <div class="toolbar"><div class="search-in">${ico('search')}<label class="sr" for="entq">Search entities</label><input id="entq" class="inp" placeholder="Search values…" value="${esc(UI.entq || '')}"></div><label class="sr" for="entCase">Case</label><select id="entCase" class="gsel bord"><option value="">All cases</option>${DB.cases.map(c => `<option value="${c.id}"${ec === c.id ? ' selected' : ''}>${esc(c.name.split(' — ')[0])}</option>`).join('')}</select><div class="seg">${[['','All ' + g.length],['malicious','Malicious'],['cross','In 2+ cases']].map(([v, l]) => `<button data-act="entKind" data-v="${v}" aria-pressed="${(UI.entKind || '') === v}">${l}</button>`).join('')}</div><span style="flex:1"></span><span class="t3">${list.length} shown</span><button class="btn" data-act="entExport">${ico('download','sm')}Export CSV</button></div>
    ${typeof psSection === 'function' && !eq && !ec && !UI.entKind ? psSection() : ''}
    <section class="card" style="overflow-x:auto"><table class="tbl cardify"><thead><tr><th>Entity</th><th>Verdict</th><th style="text-align:right">Records</th><th class="hide-m">Cases</th><th>What it is</th></tr></thead><tbody>
    ${list.slice(0, 150).map(e => { const m = E.meaning(e.k, e.v);
      return `<tr data-act="selEnt" data-id="${esc(e.id)}"><td><div style="display:flex;gap:10px;align-items:center;min-width:0">${kindBadge(e.k,'sm')}<div style="min-width:0"><div class="v">${esc(e.v)}</div><div class="t3" style="font-size:calc(12.5px * var(--ts,1))">${esc(E.LABEL[e.k] || e.k)}</div></div></div></td>
        <td>${vdLabel(verdictOf(e.id)) || '<span class="t3">—</span>'}</td><td class="n">${e.recs.length}</td><td class="hide-m"><div class="wrap" style="gap:4px">${[...e.cases].filter(theCase).slice(0, 3).map(cid => { const o = theCase(cid); return `<a class="ce-case" href="${caseHash(cid, 'entities')}" style="--cc:${esc(o.color)}" title="${esc(o.name)}">${esc(caseNm(o))}</a>`; }).join('')}${e.cases.size > 3 ? `<span class="t3">+${e.cases.size - 3}</span>` : ''}</div></td><td class="t2 hide-m" style="font-size:calc(13.5px * var(--ts,1))">${m ? esc(m.t) : '—'}</td></tr>`; }).join('')}
    </tbody></table>${list.length ? '' : g.length ? empty('search', 'Nothing matches', 'Clear the search or pick another case or filter.') : empty('fingerprint', 'No entities yet', 'IPs, domains, emails, hashes and handles are picked out of everything you capture, in every case.', `<button class="btn primary" data-act="capture">${ico('plus','sm')}Capture evidence</button>`)}</section></div></div>`;
}


function decodeChain(input){
  const steps = []; let cur = String(input || '').trim();
  const printable = s => s.length ? [...s].filter(c => { const k = c.charCodeAt(0); return k === 9 || k === 10 || k === 13 || (k >= 32 && k < 127) || k >= 160; }).length / s.length : 0;
  for(let n = 0; n < 6; n++){
    const t = cur.trim(); if(t.length < 8) break;
    if(/%[0-9a-f]{2}/i.test(t)){ try{ const d = decodeURIComponent(t.replace(/\+/g, ' ')); if(d !== t){ cur = d; steps.push(['URL-decode', cur]); continue; } }catch(e){} }
    let blob = t.replace(/\s+/g, ''), pre = '';
    if(!/^[A-Za-z0-9+/_-]+={0,2}$/.test(blob)){ const m = [...t.matchAll(/[A-Za-z0-9+/]{24,}={0,2}/g)].sort((a, b) => b[0].length - a[0].length)[0]; if(!m) break; blob = m[0]; pre = 'Blob from the line → '; }
    let bytes, op;
    if(/^[0-9a-f]+$/i.test(blob) && blob.length % 2 === 0 && blob.length >= 16){ bytes = new Uint8Array(blob.match(/../g).map(h => parseInt(h, 16))); op = 'hex'; }
    else { try{ bytes = Uint8Array.from(atob(blob.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0)); op = 'base64'; }catch(e){ break; } }
    let out = new TextDecoder().decode(bytes);
    if(bytes.length >= 8 && bytes[1] === 0 && bytes[3] === 0){ out = new TextDecoder('utf-16le').decode(bytes); op += ' → UTF-16LE'; }
    if(printable(out) < .85) break; cur = out; steps.push([pre + op, cur]);
  }
  return steps;
}
/* Reference = reference.js plus the optional pack (new sections, extra rows, groups and search keywords). */
let REF_ALL = null;
function refAll(){
  if(REF_ALL) return REF_ALL;
  const P = typeof REFPACK !== 'undefined' ? REFPACK : {}, grp = Object.assign({ports:'Network & web'}, P.group || {}), extra = P.extra || {}, out = {};
  const prep = r => { const t = (r[0] + ' ' + r[1]).toLowerCase(); return {r, v:String(r[0]).toLowerCase(), t:String(r[1]).toLowerCase(), all:(r.slice(0, 5).join(' ') + ' ' + (r[6] || '')).toLowerCase(), alias:String(r[6] || '').toLowerCase(), head:t}; };
  for(const [k, S] of Object.entries(REFDATA)){ const seen = new Set(S.rows.map(r => String(r[0]))); out[k] = {...S, group:grp[k] || S.group || 'Windows', rows:S.rows.concat((extra[k] || []).filter(r => !seen.has(String(r[0]))))}; }
  for(const [k, S] of Object.entries(P.sections || {})) if(!out[k]) out[k] = {...S, group:S.group || 'More'};
  const PFX = {aadsts:'aadsts'};
  for(const [k, S] of Object.entries(out)){ S.idx = S.rows.map(prep); if(PFX[k]) for(const x of S.idx){ x.alt = PFX[k] + x.v; x.all += ' ' + x.alt; } }
  const order = ['Windows', 'Linux & macOS', 'Network & web', 'Cloud & identity', 'Forensics', 'OSINT', 'Malware & crypto'];
  const groups = [...new Set(Object.values(out).map(S => S.group))].sort((a, b) => ((order.indexOf(a) + 1) || 99) - ((order.indexOf(b) + 1) || 99));
  return REF_ALL = {secs:out, groups};
}
/* Score a row for a query: exact value > value prefix > title > keywords > text. 0 = no match. */
function refScore(x, words, q){
  if(!words.length) return 1; if(!words.every(w => x.all.includes(w))) return 0;
  let s = 1; if(x.v === q || x.alt === q) s += 100; else if(x.v.startsWith(q)) s += 40; else if(x.v.includes(q)) s += 20;
  for(const w of words){ if(x.t.includes(w)) s += 8; if(x.alias.includes(w)) s += 5; if(x.v.includes(w)) s += 6; }
  return s;
}
const refMark = (text, words) => { let h = esc(text); if(!words.length) return h; const re = new RegExp('(' + words.map(w => esc(w).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'gi'); return h.replace(re, '<mark>$1</mark>'); };
function refDetail(cur){
  if(!cur) return ''; const [k, S, r] = cur;
  return `<aside class="rf2-d${UI.refOpen ? ' open' : ''}" id="refDet" aria-label="${esc(r[0])} details">
      <div class="rf2-dh"><span class="ix">${ico(S.icon,'sm')}${esc(S.name)}</span><button class="iconbtn rf2-x" data-act="refRowX" aria-label="Close">${ico('x','sm')}</button></div>
      <div class="rf2-k${String(r[0]).length > 14 ? ' long' : ''}">${esc(String(r[0])).replace(/([\\/])/g, '$1​')}</div><h2>${esc(r[1])}</h2>
      ${r[5] ? '<span class="rf2-hot">Worth a look</span>' : ''}
      <h5>What it means</h5><p>${esc(r[2])}</p>
      <h5>What to look for</h5><p>${esc(r[3])}</p>
      ${r[4] ? `<h5>MITRE ATT&amp;CK</h5><p><a class="rf2-att" href="https://attack.mitre.org/${/^TA/.test(r[4]) ? 'tactics' : 'techniques'}/${esc(r[4].replace('.', '/'))}/" target="_blank" rel="noopener noreferrer">${esc(r[4])} ${ico('arrow-up-right','sm')}</a></p>` : ''}
      ${r[6] ? `<h5>Also known as</h5><p class="rf2-aka">${String(r[6]).split(/\s*[,;]\s*|\s{2,}/).filter(Boolean).slice(0, 12).map(w => `<button class="chip" data-act="refAka" data-v="${esc(w)}">${esc(w)}</button>`).join('')}</p>` : ''}
      <div class="rf2-a"><button class="btn primary sm" data-act="refFind" data-v="${esc(String(r[0]).replace(/^.*\\/, ''))}">${ico('search','sm')}Search my evidence</button><button class="btn sm" data-act="flagCopy" data-v="${esc(r[0])}">${ico('copy','sm')}Copy</button></div>
      ${S.note ? `<p class="rf2-note">${esc(S.note)}</p>` : ''}</aside>`;
}
/* Picking a row updates only the row highlight and the details panel, so the page doesn't redraw. */
function refSelect(v, open){
  const i = v.indexOf(':'), k = v.slice(0, i), val = v.slice(i + 1), S = refAll().secs[k], r = S && S.rows.find(x => String(x[0]) === val); if(!r) return;
  UI.refRow = v; if(open) UI.refOpen = true;
  document.querySelectorAll('.rf2-r.on').forEach(b => b.classList.remove('on')); const btn = [...document.querySelectorAll('.rf2-r')].find(b => b.dataset.v === v); if(btn) btn.classList.add('on');
  const d = $('refDet'); if(d){ d.outerHTML = refDetail([k, S, r]); const n = $('refDet'); if(n) n.scrollTop = 0; }
  if(UI.refOpen && !document.querySelector('.rf2-scrim')){ const sc = document.createElement('div'); sc.className = 'rf2-scrim'; sc.dataset.act = 'refRowX'; const body = document.querySelector('.rf2-body'); if(body) body.appendChild(sc); }
  return btn;
}
function viewReference(){
  const A = refAll(), q = (UI.refQ || '').trim().toLowerCase(), words = q.split(/\s+/).filter(Boolean), only = !!UI.refHot;
  const grp = A.groups.includes(UI.refGrp) ? UI.refGrp : 'all', cat = A.secs[UI.refCat] && (grp === 'all' || A.secs[UI.refCat].group === grp) ? UI.refCat : 'all';
  const scored = Object.entries(A.secs).map(([k, S]) => [k, S, S.idx.map(x => [x, refScore(x, words, q)]).filter(([x, sc]) => sc && (!only || x.r[5]))]);
  const hitsBy = Object.fromEntries(scored.map(([k, , h]) => [k, h.length]));
  const inGrp = S => grp === 'all' || S.group === grp;
  let secs = scored.filter(([k, S, h]) => inGrp(S) && (cat === 'all' || cat === k) && h.length);
  if(words.length) secs = secs.map(([k, S, h]) => [k, S, h.sort((a, b) => b[1] - a[1])]).sort((a, b) => b[2][0][1] - a[2][0][1]);
  const total = Object.values(A.secs).reduce((n, S) => n + S.rows.length, 0), shown = secs.reduce((n, x) => n + x[2].length, 0);
  const hot = Object.values(A.secs).reduce((n, S) => n + S.rows.filter(r => r[5]).length, 0);
  const filt = words.length || only, cnt = k => filt ? hitsBy[k] : A.secs[k].rows.length;
  const grpN = g => Object.entries(A.secs).filter(([, S]) => g === 'all' || S.group === g).reduce((n, [k]) => n + cnt(k), 0);
  const key = (k, r) => k + ':' + r[0];
  const LIM = UI.refLim || 300; let left = LIM;
  const flat = secs.flatMap(([k, S, h]) => h.map(([x]) => [k, S, x.r]));
  let cur = flat.find(([k, S, r]) => key(k, r) === UI.refRow) || flat[0]; if(cur) UI.refRow = key(cur[0], cur[2]);
  const brk = h => h.replace(/([\\/])(?![^<]*>)/g, '$1​');
  const VW = {}; const vw = k => VW[k] || (VW[k] = Math.round(Math.min(34, Math.max(5, ...A.secs[k].rows.map(r => Math.max(...String(r[0]).split(/[\\/ ]/).map(w => w.length), Math.min(String(r[0]).length, 34) * .62)))) * 7.7 + 10));
  const row = (k, r) => `<button style="--vw:${vw(k)}px" class="rf2-r${cur && key(cur[0], cur[2]) === key(k, r) ? ' on' : ''}" data-act="refRow" data-v="${esc(key(k, r))}"><code>${brk(refMark(r[0], words))}</code><span class="rf2-t">${refMark(r[1], words)}</span>${r[5] ? '<em>Worth a look</em>' : '<i></i>'}<span class="rf2-at">${esc(r[4] || '')}</span></button>`;
  const list = secs.map(([k, S, h]) => { if(left <= 0) return ''; const rows = h.slice(0, left); left -= rows.length;
    return `${cat === 'all' ? `<div class="rf2-sh">${ico(S.icon,'sm')}${esc(S.name)}<small>${h.length}</small></div>` : ''}${rows.map(([x]) => row(k, x.r)).join('')}`; }).join('');
  const grpKs = grp === 'all' ? [] : Object.entries(A.secs).filter(([, S]) => S.group === grp);
  return `<div class="scroll rf2-scroll"><div class="rf2">
    <section class="rf2-ink"><div class="rf2-in">
      <span class="ix">Knowledge · offline field guide</span><h1>Reference</h1><p>What an event ID, port, path, code, file signature or search operator means, and what to check next.</p>
      <div class="search-in rf2-q">${ico('search')}<label class="sr" for="refQ">Search the reference</label><input id="refQ" class="inp" placeholder="4769, 4444, rundll32, AADSTS50126, 89 50 4E 47, site:, shimcache…" value="${esc(UI.refQ || '')}" autocomplete="off">${UI.refQ ? `<button class="iconbtn" data-act="refClear" aria-label="Clear search">${ico('x','sm')}</button>` : '<kbd>/</kbd>'}</div>
      <div class="rf2-stat"><div><b>${total.toLocaleString()}</b><small>entries</small></div><div><b>${Object.keys(A.secs).length}</b><small>sections</small></div><div><b>${hot}</b><small>worth a look</small></div><div class="rf2-keys"><kbd>↑</kbd><kbd>↓</kbd><small>move through results</small></div></div>
    </div></section>
    <div class="rf2-in rf2-body"><div class="rf4">
      <aside class="rf4-rail" aria-label="Sections">
        <button class="rf4-all${grp === 'all' ? ' on' : ''}" data-act="refGrp" data-v="all">${ico('book-open','sm')}<span>Everything</span><small>${grpN('all').toLocaleString()}</small></button>
        ${A.groups.map(g => { const n = grpN(g), open = grp === g || (filt && n && grp === 'all' && UI.refExp === g); const ks = Object.entries(A.secs).filter(([, S]) => S.group === g);
          return `<div class="rf4-g${open ? ' open' : ''}${grp === g ? ' cur' : ''}"><button class="rf4-gh" data-act="refGrp" data-v="${esc(g)}" aria-expanded="${open}"${n ? '' : ' disabled'}>${ico('chevron-right','sm')}<span>${esc(g)}</span><small>${n.toLocaleString()}</small></button>
            ${open ? `<div class="rf4-gb">${ks.map(([k, S]) => `<button class="rf4-s${cat === k ? ' on' : ''}" data-act="refCat" data-v="${k}"${cnt(k) ? '' : ' disabled'}>${ico(S.icon,'sm')}<span>${esc(S.name)}</span><small>${cnt(k)}</small></button>`).join('')}</div>` : ''}</div>`; }).join('')}
      </aside>
      <div class="rf4-main">
      <div class="rf2-tb"><span>${shown === total ? total.toLocaleString() + ' entries' : shown.toLocaleString() + ' of ' + total.toLocaleString()}${q ? ' matching “' + esc(UI.refQ) + '”' : ''}${words.length ? ' · best matches first' : ''}</span><label class="chk"><input type="checkbox" data-act="refHot" ${only ? 'checked' : ''}> Only “worth a look”</label></div>
      ${flat.length ? `<div class="rf2-g"><div class="rf2-l">${list}${shown > LIM ? `<div class="dmore"><span class="t3">Showing ${LIM} of ${shown}</span><button class="btn" data-act="refMore">Show more</button></div>` : ''}</div>${refDetail(cur)}</div>`
        : `<div class="hx2-empty">Nothing matches “${esc(UI.refQ || '')}”${grp !== 'all' ? ' in ' + esc(grp) + '. <button class="linkbtn" data-act="refGrp" data-v="all">Search everything</button>' : '.'}${only ? ' Try turning off “Only worth a look”.' : ''}</div>`}
      </div></div>
      ${UI.refOpen ? '<div class="rf2-scrim" data-act="refRowX" aria-hidden="true"></div>' : ''}
    </div></div></div>`;
}
function stub(title, sub, from, what){
  return `<div class="scroll"><div class="page narrow"><div class="ph"><div><h1>${title}</h1><div class="sub">${sub}</div></div></div>
    <section class="card"><div class="body" style="display:flex;gap:16px;align-items:flex-start"><span class="tb lg" style="--c:var(--text-3)">${ico('history')}</span>
      <div><div style="display:flex;gap:10px;align-items:center;margin-bottom:6px"><h3 style="font-size:calc(16px * var(--ts,1))">Coming soon</h3>${impl('planned')}</div>
      <p class="t2" style="margin:0 0 8px">${what}</p><p class="t3" style="margin:0;font-size:calc(13.5px * var(--ts,1))">Source: <code class="mono">${esc(from)}</code>. On the roadmap.</p></div></div></section></div></div>`;
}

function viewSettings(){
  const p = DB.prefs, seg = (k, o) => `<div class="seg">${o.map(([v, l, i]) => `<button data-act="pref" data-k="${k}" data-v="${v}" aria-pressed="${p[k] === v}">${i ? ico(i,'sm') : ''}${l}</button>`).join('')}</div>`;
  const M = [['Cases as colour-coded vaults, typed entries, add / edit forms','real'],['Toolbox with your 94 tools, categories, pin, star, add / edit','real'],['Editable graph (Cytoscape): drag, add, connect, edit, delete, layouts, PNG','real'],
    ['Evidence capture with automatic extraction','real'],['Timeline, story, questions, cited report','real'],['Feeds','mock'],['Detections, query builder, playbooks, library','planned'],['Importing your existing OSINTrix data','planned']];
  return `<div class="scroll"><div class="page"><div class="ph"><div><h1>Settings</h1><div class="sub">Stored in this browser only.</div></div></div>
    <section class="card" style="margin-bottom:18px"><div class="body" style="padding:22px"><div class="about">${logoMark(64)}<div style="flex:1;min-width:220px"><h2>${wordmark().replace('wordmark','wordmark big')}</h2>
      <div class="t2" style="margin-top:4px">${esc(BRAND.tagline)} · <span class="mono">${esc(BRAND.version)}</span></div>
      <div class="wrap" style="align-items:center;margin-top:14px"><button class="btn" data-act="showWelcome">${ico('eye','sm')}Show welcome</button><button class="btn" data-act="setupOpen">${ico('sparkles','sm')}Run setup</button></div></div>
      <p class="t3" style="margin:16px 0 0;font-size:calc(13px * var(--ts,1))">A private, browser-only OSINT workspace. Geist, Geist Mono, Inter and JetBrains Mono (OFL 1.1) · Lucide icons (ISC) · Cytoscape.js (MIT) · jsQR (Apache-2.0) · IEEE OUI list via oui-data (BSD-2) — all bundled, nothing loads from the network. <a href="#/help">Help &amp; FAQ</a></p></div></section>
    <div class="grid cols-2" style="align-items:start">
      <div class="set-col">
      <section class="card"><header><h3>Appearance</h3></header><div class="body">
        <div class="field"><span class="label">Theme</span>${seg('theme', [['dark','Dark','moon'],['light','Light','sun']])}</div>
        <div class="field"><span class="label">Text size</span>${seg('size', [['s','Small'],['m','Default'],['l','Large']])}</div>
        <div class="field"><span class="label">Density</span>${seg('density', [['comfortable','Comfortable'],['compact','Compact']])}</div>
        <div class="field" style="margin:0"><label for="tzSel">Show times in</label><select id="tzSel" data-pref="tz">${['UTC','America/New_York','America/Chicago','America/Los_Angeles','Europe/London','Europe/Berlin','Asia/Kolkata','Asia/Tokyo','Australia/Sydney'].map(z => `<option${p.tz === z ? ' selected' : ''}>${z}</option>`).join('')}</select></div></div></section>
      ${storageCard()}
      </div>
      <section class="card"><header><h3>Data</h3></header><div class="body">
        <p class="t2" style="margin:0 0 14px">Everything lives in this browser. Export regularly — see <a href="#/help">Help</a> for backup, import and reset.</p>
        <div class="wrap"><button class="btn" data-act="exportAll">${ico('download','sm')}Export everything</button>${DB.sample ? `<button class="btn" data-act="removeSample">${ico('trash-2','sm')}Remove sample data</button>` : ''}<button class="btn danger" data-act="resetDemo">${ico('undo-2','sm')}Reset to demo</button></div>
        <p class="t3" style="font-size:calc(13px * var(--ts,1));margin:12px 0 0">${DB.prefs.lastExport ? 'Last exported ' + esc(ago(DB.prefs.lastExport)) + '.' : 'Never exported.'} <a href="#/trash">Trash &amp; restore points</a> · <a href="#/security">Security &amp; audit</a>${(DB.trash || []).length ? ' · ' + DB.trash.length + ' in trash' : ''}</p>
        <div class="isec"><h4>Works offline</h4><p class="t2" style="margin:0 0 10px;font-size:calc(13.5px * var(--ts,1))">${!/^https?:$/.test(location.protocol) ? 'Opened as a file, so the app is already on this computer — nothing to set up.' : 'Keeps a copy of the app\'s own files (never your data) so it opens instantly and works with no connection.'}</p>
          ${/^https?:$/.test(location.protocol) ? `<div class="seg"><button data-act="offlineSet" data-v="on" aria-pressed="${!DB.prefs.noOffline}">${ico('wifi-off','sm')}On</button><button data-act="offlineSet" data-v="off" aria-pressed="${!!DB.prefs.noOffline}">Off</button></div>` : ''}</div>
        <div class="isec"><h4>Search history in tools</h4><p class="t2" style="margin:0 0 8px">When on, the Forensics kit lists the last 10 things you looked up in each tool. Off keeps nothing; turning it off forgets what was kept.</p>
          <div class="seg"><button data-act="toolHist" data-v="off" aria-pressed="${DB.prefs.toolHist !== 'on'}">Off</button><button data-act="toolHist" data-v="on" aria-pressed="${DB.prefs.toolHist === 'on'}">On</button></div></div>
        <div class="isec"><h4>Recent changes</h4>${DB.log.slice(0, 6).map(l => `<div class="li" style="padding:6px 0"><div class="main2"><b style="font-weight:500;font-size:calc(13.5px * var(--ts,1))">${esc(l.what)}</b></div><span class="end mono">${esc(E.fmtClock(l.at, tz()))}</span></div>`).join('') || '<span class="t3" style="font-size:calc(13.5px * var(--ts,1))">Nothing yet.</span>'}</div></div></section>
      
    </div></div></div>`;
}

function importFeedFile(){
  pickFile('.xml,.rss,.atom,text/xml', txt => {
    const doc = new DOMParser().parseFromString(txt, 'application/xml'); if(doc.querySelector('parsererror')) return toast('Not a valid RSS or Atom file');
    const g = (el, s) => { const x = el.querySelector(s); return x ? x.textContent.trim().replace(/<[^>]*>/g, ' ').slice(0, 2000) : ''; };
    const src = g(doc, 'channel > title') || g(doc, 'feed > title') || 'Imported feed';
    const items = [...doc.querySelectorAll('item, entry')].slice(0, 200).map(it => ({id:uid('f'), source:src, title:g(it, 'title') || '(untitled)', body:g(it, 'description') || g(it, 'summary'), ts:Date.parse(g(it, 'pubDate') || g(it, 'updated')) || Date.now()}));
    if(!items.length) return toast('No items in that file');
    DB.feed.push(...items); mutate('imported ' + items.length + ' feed items'); renderAll(); toast(items.length + ' items imported');
  });
}
function pickFile(accept, cb){
  const i = document.createElement('input'); i.type = 'file'; i.accept = accept;
  i.onchange = () => { const f = i.files && i.files[0]; if(!f) return; if(f.size > 209715200) return toast('That file is over 200 MB'); fileText(f).then(t => cb(t, f.name), e => toast('Could not read ' + f.name + ': ' + e.message)); };
  i.click();
}

/* ---------- Help ---------- */
function viewHelp(){
  const bytes = STORE.bytes || 0, quota = STORE.quota || 0, mb = (bytes / 1048576).toFixed(2);
  const cap = STORE.idb ? (quota ? fmtBytes(quota) : 'hundreds of MB') : '≈5 MB', pct = Math.min(100, Math.round(bytes / (STORE.idb ? (quota || 5e8) : 5 * 1048576) * 100));
  const where = !storageOK ? '<b style="color:var(--red)">Not saving</b> — this browser is blocking storage (private window, blocked site data or an embedded preview). Export before you close the tab.'
    : STORE.idb ? `Saved in IndexedDB${STORE.ls ? ' with a localStorage mirror' : ''}. ${STORE.persisted ? 'Marked persistent — the browser will not clear it to free space.' : 'Not marked persistent — under heavy disk pressure a browser may clear it. Keep backups.'}`
    : 'Saved in localStorage (IndexedDB unavailable). About 5 MB fits.';
  const last = DB.prefs.lastExport, stale = !last || Date.now() - last > 14 * 864e5;
  const feat = (icon, col, title, body) => `<div class="hx2-k hs-i">${ico(icon,'sm')}<div><h3>${title}</h3><p>${body}</p></div></div>`;
  const kb = (keys, what) => `<div class="hk hs-i"><span>${keys.map(k => `<kbd>${k}</kbd>`).join(' ')}</span><span>${what}</span></div>`;
  const qa = (q, a) => `<details class="hq hs-i"><summary>${q}${ico('chevron-down','sm')}</summary><p>${a}</p></details>`;
  const pic = n => typeof WL_IMG !== 'undefined' ? `<img class="hx2-d" src="${WL_IMG[n + '-dark']}" alt="" loading="lazy" decoding="async"><img class="hx2-l" src="${WL_IMG[n + '-light']}" alt="" loading="lazy" decoding="async">` : '';
  const start = [['capture','dashboard','Capture your first evidence','Paste a log line, a post or a WHOIS record — indicators and times come out on their own.','2 min'],
    ['tourStart','graph','Take the guided tour','Eleven stops through Op Lantern, a finished case: copilot, connected cases, timeline patterns, rules against the case, graph, media, infrastructure and automations.','3 min'],
    ['helpWelcome','phone','Take the welcome tour','What OSINTrix is for, how your data stays private, and where everything lives.','1 min']];
  const dir = [['Investigate',[['#/home','Dashboard','Open cases, activity and pinned notes'],['#/cases','Cases','Vault, timeline, graph, questions and report'],['#/notes','Notes','Sticky notes and to-dos'],['#/entities','Entities','Every indicator across every case'],['#/trash','Trash & restore points','Deleted items and snapshots']]],
    ['Research',[['#/toolbox','Toolbox','Your library of OSINT and security tools'],['#/queries','Query library','Search recipes filled from your vault'],['#/playbooks','Playbooks','Investigation checklists for a case'],['#/feeds','Threat Intel','News checked against your entities'],['#/watch','Watchlist','Entities you track']]],
    ['Lab',[['#/lab','Forensics kit','Files, PCAP, SQLite, images, email headers, identity checklist'],['#/regex','Patterns','Regex builder and log parsers: Select fields in log lines, get a tested regex for six tools'],['#/decoder','Decoder','Decode, encode, defang, hash, JWT'],['#/cloud','Cloud','Misconfig scanner, cloud log hunting, cloud & CTF field guide'],['#/ctf','CTF','Challenges, flags and write-ups'],['#/detections','Detections','Sigma and YARA, tested on your evidence']]],
    ['Data & security',[['#/security','Security & audit','Encryption, audit chain, signed reports'],['#/reference','Reference','Ports, event IDs, LOLBins, ATT&CK'],['#/settings','Settings & about','Time zone, theme and version'],['#hx-data','Back up and restore','Export, import and reset this browser']]]];
  const pop = [['backup','Back up and restore'],['another computer','Move to another computer'],['encrypt','Encrypt the workspace'],['pcap','Read a packet capture'],['share','Share a case'],['offline','Works offline?']];
  return `<div class="scroll"><div class="hx2">
    <section class="hx2-hero"><div class="hx2-in">
      <span class="ix">Help · ${esc(BRAND.name)} ${esc(BRAND.version)} · works offline</span>
      <h1>How can we help?</h1><p>Guides and answers for every part of ${esc(BRAND.name)}. Nothing here leaves your browser.</p>
      <div class="search-in hx2-q">${ico('search')}<label class="sr" for="hxq">Search help</label><input id="hxq" class="inp" placeholder="Search guides and questions — try “move to another computer”" autocomplete="off"><kbd>/</kbd></div>
      <div class="hx2-pop"><span>Popular</span>${pop.map(([q, l]) => `<button data-act="helpQ" data-v="${esc(q)}">${l}</button>`).join('')}</div>
      <p class="hx2-n" id="hxqN" hidden></p></div></section>
    <div class="hx2-in hx2-body">
      <section class="hx2-sec hx2-start"><header><h2>Start here</h2><button class="linkbtn" data-act="showWelcome">Show the welcome screen ${ico('arrow-right','sm')}</button></header>
        <div class="hx2-cards">${start.map(([act, img, t, d, m]) => `<button class="hx2-c" data-act="${act}"><span class="hx2-im">${pic(img)}</span><span class="hx2-ct"><b>${t}</b><small>${d}</small><i>${m}</i></span></button>`).join('')}</div></section>
      <section class="hx2-sec hx2-dir"><header><h2>Browse by area</h2></header><div class="hx2-cols">${dir.map(([g, xs]) => `<div><span class="ix">${g}</span>${xs.map(([h, n, d]) => h[0] === '#' && h[1] !== '/' ? `<button class="hs-i" data-act="helpGo" data-v="${h.slice(1)}"><b>${n}</b><small>${d}</small></button>` : `<a class="hs-i" href="${h}"><b>${n}</b><small>${d}</small></a>`).join('')}</div>`).join('')}</div></section>
      <section class="hx2-sec hx2-strip" id="hx-data"><div class="hx2-data">
          <span class="ix">Your data · this browser</span>
          <div class="hx2-dn"><b class="mono">${mb} MB</b><span>of ${cap}</span><span class="hx2-st${stale ? ' warn' : ''}"><i></i>${last ? 'Last backup ' + esc(E.fmtAgo(Date.now() - last)) : 'Never backed up'}</span></div>
          <span class="bar"><i style="width:${Math.max(pct, 1)}%"></i></span>
          <p>${where}</p>
          <div class="hx2-b"><button class="btn primary sm" data-act="exportAll">${ico('download','sm')}Back up everything</button><button class="btn sm" data-act="importAll">${ico('upload','sm')}Restore a backup</button><span class="sp"></span><button class="btn sm ghost hx2-rs" data-act="helpReset">${ico('triangle-alert','sm')}Reset…</button></div></div>
        <div class="hx2-keys"><span class="ix">Keyboard</span><div class="hx2-kg">${[['Ctrl K','Search everything'],['N','Capture evidence'],['E','New vault entry'],['/','Search this page'],['1 – 8','Case tabs'],['Esc','Close a panel']].map(([k, v]) => `<kbd>${k}</kbd><span>${v}</span>`).join('')}</div><button class="linkbtn" data-act="helpGo" data-v="hx-keys">All shortcuts and search syntax ${ico('arrow-right','sm')}</button></div></section>
      <section class="hx2-sec" id="hx-faq"><header><h2>Questions</h2><span class="ix">Click to open</span></header>
    <div class="card hfaq">
      ${qa('Is any of my data sent anywhere?', 'No. Cases, entries, evidence, notes, tools, queries and rules stay in this browser. The only outbound request is the optional live-feed relay described above, which receives feed URLs only.')}
      ${qa('My changes disappeared after a refresh — why?', 'Saved data belongs to one browser <i>and</i> one address. The copy you open from your disk (file://…) and the one on GitHub Pages (https://…github.io) are two different places with separate data, and so are Chrome and Firefox, or two browser profiles. Private windows, “clear data on exit” settings and embedded previews (for example a file preview inside another app) do not keep anything. The status in the top bar says “Saved in this browser” when saving works, and a red warning appears when it does not.')}
      ${qa('I cleared my browser and everything is gone. Can I get it back?', 'Only from a backup. There is no copy anywhere else — that is the point. Export regularly, and keep backups somewhere safe.')}
      ${qa('How do I move my work to another computer?', 'Export everything here, open ' + esc(BRAND.name) + ' on the other computer, and use Import backup on this page.')}
      ${qa('How do I share a case with a colleague?', 'Export the case as JSON from its ⋯ menu or the Report tab and send the file; your colleague uses <b>Import case</b> on the Cases page. For readers, use Print / PDF or Markdown. There is deliberately no cloud sharing.')}
      ${qa('Is it safe to paste malware indicators and logs?', 'Yes — everything is shown as plain text and links only open when you click them. Nothing you paste is executed or fetched.')}
      ${qa('Where are screenshots and attached files kept?', 'In this browser’s IndexedDB, next to your cases, up to 50 MB per file. Each one is hashed (SHA-256) when you add it. They are included in “Export everything” and in case exports, so a backup carries them too.')}
      ${qa('How complete are the Sigma and YARA engines?', 'They are small, honest subsets that run in the page. Sigma: selections with field modifiers (contains, startswith, endswith, re, all), wildcards, keyword lists and conditions with and/or/not and “1 of / all of”. YARA: text, hex (with wildcards, jumps and alternatives) and regex strings with nocase/wide/ascii, counts, offsets, filesize and uintXX checks. Anything else — modules such as pe or math, for-loops, aggregations — is reported as unsupported instead of silently passing.')}
      ${qa('How safe is encryption, and what if I forget the passphrase?', 'Security → Encrypt this workspace seals your cases, notes, restore points and attached files with AES-256-GCM, using a key derived from your passphrase (PBKDF2-SHA-256, 310,000 rounds). The passphrase is never stored or sent anywhere, so nobody — including us — can recover it. Forget it and the only way forward is to erase the workspace. Keep an encrypted backup somewhere safe. The app can also lock itself after a period of inactivity.')}
      ${qa('What does the audit log prove?', 'Every change is added to a hash chain, where each entry includes the hash of the one before it. Editing, removing or reordering a past entry breaks the chain, and Verify shows where. A chain-of-custody report lists every record of a case with its SHA-256, capture time and attached files, and is signed with this workspace\'s key — anyone can check it under Security → Verify a report. It proves the report was not altered after signing. It cannot stop someone with full access to your unencrypted browser from rewriting everything before a report is made, which is another reason to turn on encryption.')}
      ${qa('How do I archive a web page?', 'Open the page in your browser and press Ctrl+S (⌘+S on a Mac). In Chrome or Edge choose “Webpage, Single File” (.mhtml); in Firefox “Web Page, HTML only”. Then open Capture and click <b>Saved web page…</b>, or drop the file into Capture. You get an evidence entry with the title, URL, author, dates, text, outbound links and entities, plus the original file with its SHA-256. Open it later from the entry’s attachments.')}
      ${qa('Can it read packet captures?', 'Yes — Forensics kit → PCAP opens .pcap and .pcapng files. You see conversations, hosts, DNS, DHCP, HTTP (with files), TLS server names and JA3 fingerprints, cleartext logins, and findings such as beacons, scans and ARP spoofing. Encrypted traffic cannot be decrypted without its keys, but its metadata is still shown. “Send events to timeline” adds the lookups, requests and connections to a case.')}
      ${qa('How do I look at browser history or phone databases?', 'Forensics kit → SQLite opens any SQLite file: Chrome, Edge, Brave, Firefox and Safari history, cookies and saved-login lists (passwords stay encrypted), Android SMS and call logs, iPhone messages, WhatsApp. Dates are converted for you. “Deleted data” shows text left on free pages by deleted rows. The file is opened as a copy, so the original never changes.')}
      ${qa('Why does a form refuse to save?', 'A red message under the field says what to fix: a required field is empty, a value is in the wrong format (email, domain, IP, URL, CVE, hash, date, ATT&amp;CK ID, regular expression), or the name is already used. Cases, tools, queries, rules, playbooks, parsers, CTF events and challenges, and hypotheses need unique names so you can tell them apart. For a likely duplicate — the same vault entry or tool address twice — you get a warning, and pressing Save again keeps both.')}
      ${qa('How can I tell a copy from the original?', 'Duplicates are named “… (copy)”, then “… (copy 2)” and so on, and appear right after the original. Imported items whose name is already taken get “(imported)”.')}
      ${qa('Does the map send my locations anywhere?', 'Not with the default outline map, which is drawn from data inside the app. Streets and light maps download tiles from CARTO, and the satellite map from Esri. Those servers see which area you are looking at (never your case), so the app asks before switching. If tiles cannot be loaded — offline, or blocked on your network — it tells you and goes back to the outline map.')}
      ${qa('Is it safe to open a saved web page?', 'Yes. A saved .html or .mhtml page is read without running it, and the original is viewed in a sandbox with scripts off. The app blocks every outside request, so tracking pixels and remote images never load. Images and SVG files you attach are shown as pictures, which cannot run code.')}
      ${qa('Why does “Open all” in the research checklist only open one tab?', 'Browsers allow one new tab per click unless you allow pop-ups for the site. Allow them once, or use “Open next”, which ticks each lookup off as you go.')}
      ${qa('Which log formats are understood?', 'JSON, CEF, LEEF, Windows event XML (single events or a whole Event Viewer export), Apache/Nginx access logs, IIS/W3C and Zeek (TSV with #fields, or JSON), Cisco ASA, sshd/sudo, firewall flow lines (allow tcp 10.0.0.5:51022 -> 203.0.113.47:4444), Windows events copied as text, and key=value logs. AWS CloudTrail, Okta and Microsoft 365 audit logs — including the CSV export with the event in AuditData — are read as who did what, from where, and the outcome. Anything else: add your own parser with named groups in Investigate → Parse.')}
      ${qa('Why is an entity missing from the graph?', 'The graph draws vault entries, so extracted indicators stay off it until you add them — nothing clutters it without asking. The graph tells you how many are waiting. <b>Choose…</b> lets you tick the ones you want, <b>Add by rule…</b> adds by kind with filters, and the Entities tab and the capture “Add to graph” switch do the same.')}
      ${qa('How does the graph link things on its own?', 'Only when the evidence says so. A URL is linked to its domain, an email to its domain and a profile to its handle. DNS answers, Sysmon connections, email From/To/Reply-To, WHOIS registrant and name servers, and zone-file lines become relationships. So do phrases such as “resolves to”, “beacons to”, “hosted on” or “aka” placed directly between two indicators. Everything else — seen in the same record, within two minutes on one host, look-alike usernames, a shared IP or registrant — is only offered under <b>Suggested links</b>, with the reason, for you to accept or dismiss. Auto-created links are grey, and dashed when their confidence is low.')}
      ${qa('Where do the cloud, Tor and disposable-email labels come from?', 'From lists bundled with the app, so nothing is looked up online: cloud IPv4 ranges (AWS, Google Cloud, Azure, Oracle, DigitalOcean, Linode, Cloudflare, Vultr, Telegram) via lord-alfred/ipranges, Tor exit nodes via SecOps-Institute/Tor-IP-Addresses, and disposable email domains via disposable-email-domains — all snapshots from ' + esc(typeof ENR !== 'undefined' && ENR && ENR.date ? ENR.date : 'September 2026') + '. Dynamic DNS, URL shorteners, paste sites and free-hosting lists are built in. Treat them as hints, not verdicts: Tor exits and cloud ranges change daily.')}
      ${qa('Does reverse image search upload my picture?', 'No. The buttons open TinEye, Google Lens, Bing and Yandex in a new tab; you drop the image there yourself. Everything else in the image tools happens in the page.')}
      ${qa('Does it work offline?', 'Yes. Fonts, icons and every library ship with the app itself — nothing loads from a CDN. When you open it from a website, it also keeps a copy of its own files (never your data) so repeat visits open without downloading anything and it keeps working with no connection; Settings → Data turns that on or off. There is also a one-file offline copy you can make with tools/bundle.py.')}
      ${qa('What does Timeline → Rules show?', 'Every rule you have, run over the case. <b>Caught</b>: which rules fired and on which events. <b>Not caught</b>: events that look suspicious (the evidence reader, a technique ID, an attack-stage tag or a malicious verdict says so) but no rule fires on — events of the same kind are grouped, and one click drafts a rule for a whole group, with a preview of whether it would also match other evidence. <b>Noisy here</b>: rules firing on more than a fifth of the case.')}
      ${qa('How do I see what changed in a rule, or go back?', 'Open the rule → <b>History</b>. Every save that changes it keeps the version it replaces (the last 25). Pick two to compare line by line; <b>Put in editor</b> brings an old one back — nothing changes until you save, and that save keeps the one it replaces too. The line at the top of each rule sums up its tests, history, where it fires and look-alikes; each part opens its detail.')}
      ${qa('How do I move rules to another computer?', 'Pick rules in Detections and press Download: one rule is its .yml or .yar file, several are a zip with a JSON bundle that keeps tests and history. On the other computer, Import takes the zip (or .yml, .yar, .json) and shows what is new, what you already have and what clashes with one of yours by title — keep both, replace yours (yours stays in its history), or skip. One Undo takes it all back.')}
      ${qa('What is a hunt?', 'A search or one of your Sigma rules, saved and run across every case (Detections → Hunts, or the crosshair next to the timeline filter). What it finds when you save it counts as seen; anything new that matches later is flagged on the hunt and on Today until you mark it seen.')}
      ${qa('How does a case know it is connected to another?', 'Case → Overview → Connected cases lists the cases that share indicators or vault entries with this one (phones, wallets and handles compared the way duplicate detection does), weighted by your verdicts, plus nearby infrastructure — the same /24 or registered domain — which counts for less. Private addresses, benign indicators and things in most of your cases are ignored.')}
      ${qa('Why does a verdict say it is old?', 'Verdicts age: the date is kept when you set one, and its weight halves every 90 days for IPs, four months for URLs, six for domains and a year for emails, handles and wallets. File hashes never fade. Old verdicts count for less when linking cases, and Today asks you to check stale ones again. Verdicts from before dates were kept never fade.')}
      ${qa('What are Sessions and clocks that disagree?', 'In Timeline → Patterns. <b>Sessions</b> split each host’s events where it goes quiet and list the attack stages each passes through; the same run of stages on a second host later is pointed out as a likely sign of lateral movement. <b>Clocks that disagree</b>: the same indicator seen by two sources a steady time apart means one clock is off (whole hours: a time zone read wrongly). You can correct that source’s times; corrected events show a clock mark and can be put back from any of them.')}
      ${qa('Can I turn selected events into notes?', 'Yes. In the timeline press Select, pick events, then <b>Write a note</b>. It writes a short summary — how many events, hosts and time span, the attack stages, malicious indicators, what stands out — then the chronology. Each line ends with a citation like [3] that opens that event, and the note can show all its cited events as a timeline filter.')}
      ${qa('What is the Infrastructure tab?', 'Each case has one, for what the case pivots on. <b>Domains &amp; addresses</b>: paste WHOIS, RDAP, dig, passive DNS, crt.sh, Shodan or Censys results and see what the domains share (registrant, name servers, certificates, addresses). <b>Money</b>: paste explorer data for Bitcoin, Ethereum or TRON and see who paid whom, owners grouped by common inputs. <b>Accounts</b>: when each account was made, its earlier names, and pages or profiles saved more than once compared version by version. <b>Active hours</b>: when the people behind the accounts are awake. Nothing is looked up — you paste what you got.')}
      ${qa('How does Active hours guess a time zone?', 'From when someone does not post. Most people sleep around 01:00–07:00 local time, so the quietest six hours in a row place their clock. Paste a Telegram or Discord chat export, Reddit, Mastodon or X data, a JSON list or CSV with times, or one time per line. You also see their weekend (Saturday–Sunday or Friday–Saturday), whether their clock changes for summer, and which accounts keep the same week — one person behind two names, or a team on one shift. Twenty posts or more give a usable guess; accounts that post at every hour are flagged as automated or shared.')}
      ${qa('What does the identity checklist do?', 'Forensics kit → Identity pivots. For a username, email address or phone number it lists every place worth checking: profiles, breach and leak searches, search-engine queries, messaging apps, and archived copies of each profile. Mark each there, not there or private, add a note, and save a found profile to the case as evidence. It is kept with the value, across cases, and <b>Copy what was found</b> gives a summary for your notes. Nothing is looked up for you; you open each place yourself.')}
      ${qa('What is an identity profile?', 'Open a Person in the vault → <b>Identity profile</b>, or Vault → Identity profiles for everyone. It gathers the handles, emails, phones and wallets linked to that person, how sure each link is (from the confidence on the relationships), and the same identifier in other cases — so one person under different names comes together. Shared emails, phones and wallets confirm; a shared username only makes it likely. Where cases disagree, for example on a date of birth, it says so, and lists the gaps still to close.')}
      ${qa('How do I see what changed on a page?', 'Save the page again later (Ctrl+S, then Capture → Saved web page), or paste the profile data again. Infrastructure → Accounts → <b>Changes over time</b> sets each version against the one before: text added and removed, links, email addresses, and for profiles every field — name, bio, picture, follower counts with how much they moved. <b>Compare two records</b> does the same for any two pieces of evidence.')}
      ${qa('Which files give up their metadata?', 'Photos (JPEG, PNG, WebP, HEIC, TIFF), videos (MP4, MOV), MP3, PDF, Word, Excel and PowerPoint — both the newer .docx/.xlsx/.pptx and the old .doc/.xls/.ppt — and OpenDocument (.odt, .ods, .odp). You see who made and last saved a document, when, with which program and template, how many times it was edited and for how long, and where a photo or video was taken. It is read when you attach a file and in Forensics kit → File inspector.')}
      ${qa('What does a phone number tell me offline?', 'Its country, whether it is mobile, landline, VoIP, toll-free, premium or a personal “follow-me” number, whether it is valid in that country’s numbering plan, whether it sits in a range kept for films and TV, and one standard form — so +44 7700 900123 and 07700 900123 are matched as the same number across cases. Set the country for numbers written without a code in the number’s details panel.')}
      ${qa('How long can a note or a paste be?', 'One-line fields take up to 4,096 characters, text boxes up to 5 million (enough for a large log or chat export), a notebook page up to 2 million. A paste that goes over is cut and says so — import big files instead. Files have their own limits: 25 MB for one log import, 50 MB for an attachment.')}
      ${qa('How do I build a regular expression for a log?', '<b>Patterns</b> in the sidebar (under Kit, or type “regex” in search), on the Build a pattern tab. Paste some lines (or open a log file), select a part of a line — an IP address, a user name, a time — and name it. The builder writes the pattern: a precise one for things it recognises (IP addresses, timestamps, email addresses, hashes, numbers), “up to the next delimiter” for the rest, never a loose <span class="mono">.*</span>. It tries the pattern on every line; on a line it misses, select the same fields and it learns that variation (“Failed” or “Accepted”, an optional “invalid user”). It warns about patterns that can freeze a log tool, and gives you the pattern for JavaScript, PCRE, Python, Grok, Splunk and KQL — or saves it as a parser for log imports. Your lines never leave the browser and are not kept.')}
      ${qa('Can it handle a log with several formats, or stack traces?', 'Yes. <b>Auto-parse</b> in Patterns → Build a pattern sorts mixed lines into formats (sshd, sudo, cron, a firewall…) and names the fields of the layouts it knows — key=value, JSON, CSV/TSV, CEF, LEEF, syslog, Apache/nginx, IIS and Windows “Key: value” exports. Records over several lines (Java stack traces, Event Viewer text exports) are joined first, and Export gives the same record setting for Logstash, Filebeat, Splunk and Fluent Bit. Click a missed line to see where the pattern stops; <b>Explain</b> reads the pattern back in plain words; <b>Speed</b> makes it faster only where every line still gives the same values.')}
      ${qa('Is there a quick way to look something up?', 'Right-click any indicator — an IP, domain, URL, email, hash, handle, wallet or CVE — anywhere in OSINTrix: copy it (plain or defanged), open its details, find it in every case, watch it, or open it in VirusTotal, Shodan, crt.sh, the Wayback Machine and the other lookups for its kind. Select part of a line first to use just that. Shift + right-click gives the browser’s own menu.')}
      ${qa('How do I keep a version of a case before a big change?', 'Open the case’s ⋯ menu → Save a snapshot to your computer. The file goes to your downloads and takes no space in this browser. Later, ⋯ → Compare with a snapshot shows what was added, removed and edited since; you can bring back only what was removed, or roll the whole case back (the case as it is now is downloaded first). Undo works after both.')}
      ${qa('Can I save a filter or search I use often?', 'Yes. In the Vault, set the filters and sort, then Save view; on the Board, focus or filter and Save view; in Ctrl K, type the search and Save search. Vault views are listed in the vault’s side panel, graph views on the graph bar, and every view in Ctrl K — type its name.')}
      ${qa('How do I link a note to a vault entry?', 'Type @ in the note and pick the entry from the list (↑ ↓, then Enter or Tab). It is written as @[value] and becomes a link; the entry shows the note under Mentioned in notes.')}
      ${qa('Can OSINTrix fill up my browser storage?', 'It checks first. Before a vault import, a case import, a backup restore or a log import, it asks the browser how much room is left; if the import would not fit, nothing is changed and you are told what is needed. Restore points make room by dropping their oldest copies, or are skipped. Settings → Storage shows what is using the space; case snapshots are saved as files on your computer, not here.')}
      ${qa('The graph of a big case is a tangle — how do I read it?', 'Board → Focus on… and type the entry you care about, or right-click a node → Focus here. Only what is 1, 2 or 3 steps away is drawn, laid out around it; Expand on a node brings in what links to it. Narrow by verdict or tag, or Hide single links to drop the loose ends. Show all goes back to the whole graph, which keeps its own layout.')}
      ${qa('Can I bring in work from Maltego or SpiderFoot?', 'Yes — Vault → Import. It takes a Maltego graph (.mtgx, or a graph exported as GraphML), any GraphML, a SpiderFoot scan exported as CSV, or a CSV of values or of links. Before anything is added you see what each kind of thing becomes and can change or skip it; entries already in the case are reused, not duplicated. Undo takes the whole import back.')}
      ${qa('How do I work through a case with thousands of entries?', 'In the Vault, filter by verdict, type and tag, or show only what is not linked to anything, also in other cases, watched or never seen in a record; sort by priority, date, records or value. Tick the box on a card or row — Shift+click for a range, or Select all shown — and set the priority or verdict, tag, star, watch, export or delete them together. Each change can be undone from the message that follows.')}
      ${qa('Can I filter Ctrl K search?', 'Yes. Add verdict:malicious, type:ip, tag:phishing or is:watched (also starred, open, solved) to any search, together with case:op-lantern (a case’s name) or in:tools. Start typing one and the operators and their values are suggested; Tab finishes it. With a result highlighted, Alt+1 to Alt+9 copy it, watch it, open a lookup and so on, without leaving the search.')}
      ${qa('How do I write a search for Google, Shodan or GitHub without remembering the operators?', 'Query library → Build a search. Add a row for each thing you want — a site, a file type, words in the title, a port, a country, a code language — and the search is written for every engine at once; switch engines with the tabs along the top. Anything an engine cannot search by is struck through and named. Put a blank like {{DOMAIN_NAME}} in a row and save it: it becomes a template you fill from a vault entry, and it is rewritten for whichever engine you run it on.')}
      ${qa('How do I share a log without the names and addresses in it?', 'Use Copy masked: on a record’s captured text, at the top of the Scratchpad, in Patterns → Build a pattern (Mask a copy), in the Decoder (Mask identifiers), or by selecting any text and right-clicking it. IP addresses, domains, emails, user names, host names, hashes, MAC addresses, phones and wallets are replaced by placeholders of the same shape, with the same value always getting the same placeholder, so the log still reads and still parses. It all happens in this browser.')}
      ${qa('How do I stop a pattern breaking when I change it?', 'Pin lines as tests: in Patterns → Build a pattern, on the Match tab, “Pin as test: must match” keeps a line and the values it gives; “must not match” keeps one it must leave alone; the Tests tab takes pasted lines too. Every change is checked against them and the pattern bar shows how many pass. Export shows which tools can run the pattern — KQL (RE2) has no lookahead, so it gets a version without it when that gives the same values.')}
      ${qa('Is the trash for everything?', 'Yes. Deleted cases, records, vault entries, notes, links, rules, saved queries, hunts, playbooks, tools and automations all go to Trash in the sidebar for 30 days, and Restore brings each back — also after a refresh.')}
    </div>
      </section>
      <section class="hx2-sec" id="hx-know"><header><h2>Things to know</h2></header><div class="hx2-know">
      ${feat('lock','#10b981','Privacy first','Everything you add is saved only in this browser (IndexedDB, with a localStorage copy). Every change is saved as soon as you make it and survives reloads and restarts. Nothing is uploaded. The page’s security policy blocks every outside connection except one you opt into (below).')}
      ${feat('download','#3b82f6','Back up regularly','Because data lives in this browser, clearing site data, using a private window or switching browsers means starting empty. Export a JSON backup often — you can import it on another device. Deleted items wait 30 days in the trash, and a restore point is saved before every import, reset or clean-up.')}
      ${feat('rss','#f59e0b','The one network request','Threat Intel is offline until you turn on live feeds. Then only the feed addresses are sent to <span class="mono">api.rss2json.com</span>, the relay the original app used. Your cases never are.')}
      ${feat('wrench','#8b5cf6','Pre-added tools &amp; updates','Default tools come from <span class="mono">tools.json</span>. Delete one and it stays deleted. When the app ships new pre-added tools they are added to your toolbox without touching your own tools, stars or pins.')}
      ${feat('external-link','#ec4899','Opening tools and searches','Tools and query-library searches open in a new tab on the site you chose. What you type into those sites is between you and them — ' + esc(BRAND.name) + ' only logs the search to your case if you tick “Log to case”.')}
      ${feat('maximize','#06b6d4','Best on a larger screen','Everything works on a phone, but the graph, timeline and rule editor are happiest on a laptop or desktop.')}
      </div></section>
      <section class="hx2-sec" id="hx-keys"><div class="hcols">
      <section><h2 class="hh">Keyboard shortcuts <span class="t3" style="font-size:calc(13px * var(--ts,1));font-weight:400">— press <kbd>?</kbd> anywhere for this list</span></h2><div class="card keys">${typeof keysHtml === 'function' ? keysHtml() : ''}</div></section>
      <section><h2 class="hh">Search syntax</h2><div class="card hkeys">
        <p class="t2" style="margin:0 0 10px;font-size:calc(13.5px * var(--ts,1))">The filter box on a case's Timeline tab (or the top search, which offers it) narrows the records. Combine words with filters:</p>
        ${[['in:tools shodan','Search one area (cases, vault, evidence, indicators, notes, tools, queries, rules, playbooks, ctf, news)'],['case:op-lantern dns','Only inside one case (its name, or its TN- number)'],['"lamp loader" -firewall','Exact phrase, exclude a word'],['host:DC01','Records from one machine'],['verdict:malicious','Only bad indicators'],['type:finding','Findings, notes, questions…'],['tag:intel','Records with a tag'],['after:2026-09-14','Time windows (also before:)'],['source:sysmon','Where the evidence came from']].map(([c, d]) => `<div class="hk hs-i"><code class="mono">${c}</code><span>${d}</span></div>`).join('')}</div></section>
      </div></section>
      <p class="hx2-empty" id="hxqE" hidden></p>
    <p class="hfoot">${esc(BRAND.name)} ${esc(BRAND.version)} · Inter &amp; JetBrains Mono (OFL 1.1) · Lucide icons (ISC) · Cytoscape.js (MIT) · jsQR (Apache-2.0) · IEEE OUI vendor list via oui-data (BSD-2) · cloud ranges &amp; disposable domains (CC0) · Natural Earth map (public domain) · <a href="#/settings">Settings &amp; about</a> · <button class="linkbtn" data-act="showWelcome">Show the welcome screen</button></p>
    </div></div></div>`;
}
