/* Default toolbox. New entries appear in everyone's toolbox on next load; deleted ones stay deleted.
   Plain JSON after the "=" — edit it like a .json file. Loaded as a script so the app also works from file://. */
const TOOLS_SEED = [
  {
    "id": 1,
    "name": "Maltego",
    "url": "https://www.maltego.com",
    "parentCategory": "general",
    "childCategory": "all-tools",
    "description": "Comprehensive link analysis and data mining application for gathering and connecting information for investigative tasks.",
    "tags": [
      "investigation",
      "link-analysis",
      "osint",
      "commercial"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-15"
  },
  {
    "id": 2,
    "name": "Shodan",
    "url": "https://www.shodan.io",
    "parentCategory": "osint",
    "childCategory": "search-engines",
    "description": "Search engine for Internet-connected devices. Find exposed databases, webcams, industrial systems, and more.",
    "tags": [
      "iot",
      "search",
      "reconnaissance",
      "devices"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-01-14"
  },
  {
    "id": 3,
    "name": "VirusTotal",
    "url": "https://www.virustotal.com",
    "parentCategory": "malware-analysis",
    "childCategory": "file-analysis",
    "description": "Free online service that analyzes files and URLs for viruses, worms, trojans and other malicious content.",
    "tags": [
      "malware",
      "analysis",
      "free",
      "hash-lookup"
    ],
    "isPinned": true,
    "isStarred": false,
    "dateAdded": "2024-01-13"
  },
  {
    "id": 4,
    "name": "Wireshark",
    "url": "https://www.wireshark.org",
    "parentCategory": "network-security",
    "childCategory": "packet-analysis",
    "description": "World's foremost and widely-used network protocol analyzer for troubleshooting, analysis, and protocol development.",
    "tags": [
      "network",
      "packet-capture",
      "analysis",
      "free",
      "open-source"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-12"
  },
  {
    "id": 5,
    "name": "Autopsy",
    "url": "https://www.autopsy.com",
    "parentCategory": "digital-forensics",
    "childCategory": "disk-analysis",
    "description": "Digital forensics platform and graphical interface to The Sleuth Kit and other digital forensics tools.",
    "tags": [
      "forensics",
      "disk-analysis",
      "free",
      "open-source"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-11"
  },
  {
    "id": 6,
    "name": "MISP",
    "url": "https://www.misp-project.org",
    "parentCategory": "threat-intelligence",
    "childCategory": "threat-sharing",
    "description": "Open source threat intelligence platform for sharing, storing and correlating Indicators of Compromise.",
    "tags": [
      "threat-intel",
      "ioc",
      "sharing",
      "open-source"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-01-10"
  },
  {
    "id": 7,
    "name": "TheHive",
    "url": "https://thehive-project.org",
    "parentCategory": "incident-response",
    "childCategory": "case-management",
    "description": "Scalable, open source and free Security Incident Response Platform designed to make life easier for SOCs and CSIRTs.",
    "tags": [
      "incident-response",
      "case-management",
      "open-source",
      "soc"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-09"
  },
  {
    "id": 8,
    "name": "Nessus",
    "url": "https://www.tenable.com/products/nessus",
    "parentCategory": "compliance",
    "childCategory": "vulnerability-assessment",
    "description": "Comprehensive vulnerability scanner that identifies vulnerabilities, configuration issues, and malware.",
    "tags": [
      "vulnerability",
      "scanning",
      "compliance",
      "commercial"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-08"
  },
  {
    "id": 9,
    "name": "NRD-db",
    "url": "https://github.com/luismayta/nrd-db",
    "parentCategory": "osint",
    "childCategory": "domain-investigation",
    "description": "Automatically fetches and stores newly registered domains in a Redis database.",
    "tags": [
      "domains",
      "automation",
      "redis"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 10,
    "name": "MITRE ATT&CK Navigator",
    "url": "https://mitre-attack.github.io/attack-navigator/",
    "parentCategory": "threat-intelligence",
    "childCategory": "threat-hunting",
    "description": "Web-based tool for annotating and exploring ATT&CK matrices.",
    "tags": [
      "mitre",
      "visualization",
      "threat-modeling"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 11,
    "name": "HELK",
    "url": "https://github.com/Cyb3rWard0g/HELK",
    "parentCategory": "threat-intelligence",
    "childCategory": "threat-hunting",
    "description": "The Hunting ELK: Advanced analytics engine with Elasticsearch, Logstash, and Kibana.",
    "tags": [
      "elk",
      "hunting",
      "analytics",
      "siem"
    ],
    "isPinned": true,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 12,
    "name": "DetectionLab",
    "url": "https://github.com/clong/DetectionLab",
    "parentCategory": "incident-response",
    "childCategory": "automation",
    "description": "Vagrant & Packer scripts to build a complete lab environment with security tooling.",
    "tags": [
      "lab",
      "virtualization",
      "logging"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 13,
    "name": "Security Onion",
    "url": "https://securityonion.net/",
    "parentCategory": "network-security",
    "childCategory": "intrusion-detection",
    "description": "Linux distro for threat hunting, enterprise security monitoring, and log management.",
    "tags": [
      "ids",
      "nsm",
      "hunting",
      "linux"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 14,
    "name": "Intel Owl",
    "url": "https://github.com/intelowlproject/IntelOwl",
    "parentCategory": "threat-intelligence",
    "childCategory": "ioc-analysis",
    "description": "OSINT solution to get threat intelligence data about files, IPs, or domains via API at scale.",
    "tags": [
      "api",
      "automation",
      "threat-intel"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 15,
    "name": "YARA",
    "url": "https://virustotal.github.io/yara/",
    "parentCategory": "malware-analysis",
    "childCategory": "yara-rules",
    "description": "The pattern matching swiss knife for malware researchers.",
    "tags": [
      "malware",
      "rules",
      "hunting"
    ],
    "isPinned": true,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 16,
    "name": "Velociraptor",
    "url": "https://docs.velociraptor.app/",
    "parentCategory": "incident-response",
    "childCategory": "evidence-collection",
    "description": "Advanced endpoint visibility and collection tool for DFIR.",
    "tags": [
      "endpoint",
      "dfir",
      "monitoring"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 17,
    "name": "Cortex XSOAR",
    "url": "https://www.paloaltonetworks.com/cortex/xsoar",
    "parentCategory": "incident-response",
    "childCategory": "automation",
    "description": "Security orchestration, automation, and response platform to accelerate incident response.",
    "tags": [
      "soar",
      "automation",
      "orchestration",
      "commercial"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 18,
    "name": "OpenCTI",
    "url": "https://www.opencti.io/",
    "parentCategory": "threat-intelligence",
    "childCategory": "threat-sharing",
    "description": "Open Cyber Threat Intelligence platform to manage, share, and analyze cyber threat intelligence.",
    "tags": [
      "cti",
      "platform",
      "sharing",
      "open-source"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 19,
    "name": "Cuckoo Sandbox",
    "url": "https://cuckoosandbox.org/",
    "parentCategory": "malware-analysis",
    "childCategory": "sandboxes",
    "description": "Open source automated malware analysis system.",
    "tags": [
      "malware",
      "sandbox",
      "analysis",
      "open-source"
    ],
    "isPinned": true,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 20,
    "name": "OpenVAS",
    "url": "https://www.openvas.org/",
    "parentCategory": "compliance",
    "childCategory": "vulnerability-assessment",
    "description": "Open source vulnerability scanner and manager.",
    "tags": [
      "vulnerability",
      "scanning",
      "open-source"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 21,
    "name": "SpiderFoot",
    "url": "https://www.spiderfoot.net/",
    "parentCategory": "osint",
    "childCategory": "domain-investigation",
    "description": "Automated OSINT collection and analysis tool.",
    "tags": [
      "osint",
      "automation",
      "reconnaissance"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 22,
    "name": "FTK Imager",
    "url": "https://accessdata.com/product-download/ftk-imager-version-4-2-1",
    "parentCategory": "digital-forensics",
    "childCategory": "disk-analysis",
    "description": "Forensic imaging tool for creating forensic images of computer data.",
    "tags": [
      "forensics",
      "imaging",
      "free"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 23,
    "name": "CAPE Sandbox",
    "url": "https://capesandbox.com/",
    "parentCategory": "malware-analysis",
    "childCategory": "sandboxes",
    "description": "Automated malware analysis system based on Cuckoo Sandbox with enhanced features.",
    "tags": [
      "malware",
      "sandbox",
      "analysis",
      "open-source"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 24,
    "name": "OSQuery",
    "url": "https://osquery.io/",
    "parentCategory": "digital-forensics",
    "childCategory": "artifact-analysis",
    "description": "SQL powered operating system instrumentation, monitoring, and analytics framework.",
    "tags": [
      "endpoint",
      "monitoring",
      "analytics",
      "open-source"
    ],
    "isPinned": true,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 25,
    "name": "GRR Rapid Response",
    "url": "https://grr-doc.readthedocs.io/en/latest/",
    "parentCategory": "incident-response",
    "childCategory": "evidence-collection",
    "description": "Incident response framework focused on remote live forensics.",
    "tags": [
      "incident-response",
      "forensics",
      "open-source"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 26,
    "name": "Kolide Fleet",
    "url": "https://fleetdm.com/",
    "parentCategory": "incident-response",
    "childCategory": "automation",
    "description": "Open source osquery management server for endpoint visibility and security.",
    "tags": [
      "endpoint",
      "osquery",
      "management",
      "open-source"
    ],
    "isPinned": true,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 27,
    "name": "Cortex Analyzer",
    "url": "https://www.thehive-project.org/cortex/",
    "parentCategory": "malware-analysis",
    "childCategory": "file-analysis",
    "description": "Powerful analysis engine to analyze observables at scale.",
    "tags": [
      "analysis",
      "automation",
      "open-source"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 28,
    "name": "Sigma",
    "url": "https://sigmahq.io/docs/basics/rules.html",
    "parentCategory": "threat-intelligence",
    "childCategory": "threat-hunting",
    "description": "Generic signature format for SIEM systems to describe log events in a straightforward manner.",
    "tags": [
      "detection",
      "siem",
      "rules",
      "open-source"
    ],
    "isPinned": true,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 29,
    "name": "OpenDF",
    "url": "https://opendf.io/",
    "parentCategory": "digital-forensics",
    "childCategory": "artifact-analysis",
    "description": "Open source digital forensics platform for managing and automating forensic investigations.",
    "tags": [
      "forensics",
      "automation",
      "open-source"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 30,
    "name": "MalwareBazaar",
    "url": "https://bazaar.abuse.ch/",
    "parentCategory": "malware-analysis",
    "childCategory": "hash-lookup",
    "description": "Project by abuse.ch to share malware samples with the security community.",
    "tags": [
      "malware",
      "repository",
      "sharing",
      "free"
    ],
    "isPinned": true,
    "isStarred": false,
    "dateAdded": "2024-01-20"
  },
  {
    "id": 31,
    "name": "Brim",
    "url": "https://www.brimdata.io/",
    "parentCategory": "network-security",
    "childCategory": "traffic-analysis",
    "description": "Desktop app to efficiently search large packet captures and Zeek logs using a SQL-like query language.",
    "tags": [
      "pcap",
      "zeek",
      "analysis",
      "wireshark-plus"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 32,
    "name": "Capa",
    "url": "https://github.com/mandiant/capa",
    "parentCategory": "malware-analysis",
    "childCategory": "static-analysis",
    "description": "Mandiant's tool to identify capabilities in executable files (e.g., 'it can encrypt data' or 'it can steal passwords').",
    "tags": [
      "mandiant",
      "reverse-engineering",
      "capabilities"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 33,
    "name": "Perplexity AI",
    "url": "https://www.perplexity.ai",
    "parentCategory": "ai-automation",
    "childCategory": "llm-tools",
    "description": "AI-powered search engine that provides cited sources—perfect for verifying OSINT data points.",
    "tags": [
      "ai",
      "search",
      "verification",
      "research"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 34,
    "name": "Hugging Face",
    "url": "https://huggingface.co/",
    "parentCategory": "ai-automation",
    "childCategory": "analysis-ai",
    "description": "The 'GitHub of AI.' Access thousands of models for sentiment analysis, translation, and malware classification.",
    "tags": [
      "ml",
      "models",
      "data-science"
    ],
    "isPinned": false,
    "isStarred": true,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 35,
    "name": "Uncoder.io",
    "url": "https://uncoder.io/",
    "parentCategory": "threat-intelligence",
    "childCategory": "threat-hunting",
    "description": "Online translator for SIEM searches. Convert Sigma rules to Splunk, Sentinel, or Elastic queries.",
    "tags": [
      "sigma",
      "siem",
      "translation",
      "automation"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 36,
    "name": "Snort",
    "url": "https://www.snort.org/",
    "parentCategory": "network-security",
    "childCategory": "intrusion-detection",
    "description": "The world's leading open-source Intrusion Prevention System (IPS).",
    "tags": [
      "ids",
      "ips",
      "network",
      "open-source"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 37,
    "name": "PimEyes",
    "url": "https://pimeyes.com/",
    "parentCategory": "osint",
    "childCategory": "image-investigation",
    "description": "AI face search engine that finds pictures of people across the clear web.",
    "tags": [
      "ai",
      "facial-recognition",
      "osint",
      "privacy"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 38,
    "name": "Shuffle",
    "url": "https://shuffler.io/",
    "parentCategory": "ai-automation",
    "childCategory": "automation",
    "description": "Open-source SOAR platform (Security Orchestration, Automation, and Response) to link all your tools.",
    "tags": [
      "soar",
      "automation",
      "workflow"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 39,
    "name": "DeepL",
    "url": "https://www.deepl.com",
    "parentCategory": "ai-automation",
    "childCategory": "llm-tools",
    "description": "Highly accurate AI translator, essential for analyzing foreign-language threat actor forum posts.",
    "tags": [
      "translation",
      "ai",
      "intelligence"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 40,
    "name": "Certgrep",
    "url": "https://github.com/drfuzz0r/certgrep",
    "parentCategory": "osint",
    "childCategory": "domain-investigation",
    "description": "Fast Certificate Transparency Log regex domain lookup tool for finding subdomains.",
    "tags": [
      "recon",
      "ssl",
      "certificates",
      "cli"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-01-21"
  },
  {
    "id": 41,
    "name": "10digits",
    "url": "http://10digits.us",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "US-based search engine for finding contact information, addresses, and phone numbers.",
    "tags": [
      "people-search",
      "usa",
      "osint"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 42,
    "name": "Whitepages",
    "url": "http://www.whitepages.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Provider of online person search, background checks, and identity verification services in the US.",
    "tags": [
      "people-search",
      "background-check",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 43,
    "name": "411",
    "url": "http://www.411.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Digital directory for finding people and businesses with reverse lookup capabilities.",
    "tags": [
      "directory",
      "phone-lookup",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 44,
    "name": "Zabasearch",
    "url": "http://www.zabasearch.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Free public records search engine for identifying residents and historical address data.",
    "tags": [
      "free",
      "public-records",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 45,
    "name": "Intelius",
    "url": "http://www.intelius.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Search engine for background checks, criminal records, and detailed people profiles.",
    "tags": [
      "investigation",
      "background-check",
      "records"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 46,
    "name": "Yellow Pages",
    "url": "http://www.yellowpages.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Business and personal directory for local search and contact information.",
    "tags": [
      "business-search",
      "directory",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 47,
    "name": "PublicRecords.directory",
    "url": "http://publicrecords.directory/",
    "parentCategory": "osint",
    "childCategory": "public-records",
    "description": "Comprehensive index of official state and local public record databases.",
    "tags": [
      "public-records",
      "official",
      "government"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 48,
    "name": "411Locate",
    "url": "http://www.411locate.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Tool for locating individuals via name, phone, or address search.",
    "tags": [
      "locate",
      "people-search",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 49,
    "name": "Addresses",
    "url": "http://www.addresses.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Searchable database for residential addresses and mailing information.",
    "tags": [
      "address-lookup",
      "whitepages",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 50,
    "name": "Spokeo",
    "url": "http://www.spokeo.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Aggregates data from social media and public records to build digital profiles.",
    "tags": [
      "social-media",
      "people-search",
      "data-aggregator"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 51,
    "name": "AnyWho",
    "url": "http://www.anywho.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Find people by name or address and use reverse phone lookups.",
    "tags": [
      "people-search",
      "whitepages",
      "free"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 52,
    "name": "PeopleFinders",
    "url": "http://www.peoplefinders.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "DaaS provider for background checks, criminal records, and person searches.",
    "tags": [
      "people-search",
      "background-check",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 53,
    "name": "SkipEase",
    "url": "http://www.skipease.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Specialized skip tracing and people locator search engine.",
    "tags": [
      "skip-tracing",
      "investigation",
      "people-search"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 54,
    "name": "VetFriends",
    "url": "https://www.vetfriends.com/",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Resource for finding and reconnecting with US military veterans.",
    "tags": [
      "military",
      "veterans",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 55,
    "name": "Radaris",
    "url": "http://radaris.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Combines public records with proprietary social media data for deep backgrounding.",
    "tags": [
      "background-check",
      "public-records",
      "social-osint"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 56,
    "name": "Superpages",
    "url": "http://www.superpages.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Local business and individual directory search.",
    "tags": [
      "directory",
      "local-search",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 57,
    "name": "Nuwber",
    "url": "https://nuwber.com/",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Public record profile provider for individuals residing in the United States.",
    "tags": [
      "public-records",
      "people-search",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 58,
    "name": "192.com",
    "url": "http://www.192.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "UK's leading resource for finding people, business, and property data.",
    "tags": [
      "uk",
      "electoral-roll",
      "directory"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 59,
    "name": "Webmii",
    "url": "http://webmii.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Aggregates web search and social media visibility for global people search.",
    "tags": [
      "global",
      "social-media",
      "osint"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 60,
    "name": "Yasni",
    "url": "http://www.yasni.com",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Free search engine for finding information and contact details on any person.",
    "tags": [
      "international",
      "search",
      "people"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 61,
    "name": "PeekYou UK",
    "url": "http://www.peekyou.com/united_kingdom",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Indexes the online content of people specifically within the United Kingdom.",
    "tags": [
      "uk",
      "social-search",
      "osint"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 62,
    "name": "British Phonebook",
    "url": "http://britishphonebook.com/",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Direct directory for United Kingdom residential and commercial phone listings.",
    "tags": [
      "uk",
      "phonebook",
      "directory"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 63,
    "name": "Canada411",
    "url": "http://www.canada411.ca",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Canada's primary directory for finding local businesses and individuals.",
    "tags": [
      "canada",
      "directory",
      "people-search"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 64,
    "name": "Freeality",
    "url": "http://www.freeality.com",
    "parentCategory": "osint",
    "childCategory": "search-engines",
    "description": "Portal of search tools for Canada and international people searches.",
    "tags": [
      "canada",
      "metasearch",
      "osint"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 65,
    "name": "World 192",
    "url": "http://world.192.com/",
    "parentCategory": "osint",
    "childCategory": "people-search",
    "description": "Global extension of the 192 search platform for international discovery.",
    "tags": [
      "international",
      "directory",
      "people-search"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 66,
    "name": "SpyDialer",
    "url": "http://www.spydialer.com/",
    "parentCategory": "osint",
    "childCategory": "phone-investigation",
    "description": "Reverse phone lookup tool that allows you to hear the voicemail of a number without calling it.",
    "tags": [
      "phone-search",
      "voicemail",
      "reverse-lookup"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 67,
    "name": "PhoneValidator",
    "url": "http://www.phonevalidator.com",
    "parentCategory": "osint",
    "childCategory": "phone-investigation",
    "description": "Checks if a phone number is a landline, cell phone, or VOIP/fake number.",
    "tags": [
      "validation",
      "carrier-check",
      "telecom"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 68,
    "name": "FoneFinder",
    "url": "http://www.fonefinder.net",
    "parentCategory": "osint",
    "childCategory": "phone-investigation",
    "description": "Global search for identifying the city, state, and provider of a phone number.",
    "tags": [
      "global",
      "carrier",
      "prefix-search"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 69,
    "name": "Canada Numbers",
    "url": "http://canada.numbers.tel",
    "parentCategory": "osint",
    "childCategory": "phone-investigation",
    "description": "Specialized directory for Canadian telephone numbers and regional codes.",
    "tags": [
      "canada",
      "phone-directory"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 70,
    "name": "Numberway",
    "url": "http://www.numberway.com/",
    "parentCategory": "osint",
    "childCategory": "phone-investigation",
    "description": "A portal linking to international white pages and yellow pages directories globally.",
    "tags": [
      "international",
      "phone-search",
      "directories"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 71,
    "name": "Google Advanced Search",
    "url": "https://www.google.com/advanced_search",
    "parentCategory": "osint",
    "childCategory": "username-investigation",
    "description": "Utilize advanced dorks to find specific usernames or mentions across the web.",
    "tags": [
      "dorking",
      "search-operators",
      "username"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 72,
    "name": "Pipl",
    "url": "https://pipl.com",
    "parentCategory": "osint",
    "childCategory": "username-investigation",
    "description": "Identity resolution tool used to find the person behind an email or social handle.",
    "tags": [
      "identity-resolution",
      "professional",
      "investigation"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 73,
    "name": "CheckUsernames",
    "url": "http://checkusernames.com",
    "parentCategory": "osint",
    "childCategory": "username-investigation",
    "description": "Search for username availability and history across 160+ social networks.",
    "tags": [
      "social-media",
      "username-check"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 74,
    "name": "Knowem",
    "url": "http://knowem.com",
    "parentCategory": "osint",
    "childCategory": "username-investigation",
    "description": "Check the use of a name or brand on over 500 social networks and domains.",
    "tags": [
      "social-footprint",
      "branding",
      "recon"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 75,
    "name": "TinEye",
    "url": "http://www.tineye.com",
    "parentCategory": "osint",
    "childCategory": "image-investigation",
    "description": "Reverse image search engine specialized in image identification and tracking.",
    "tags": [
      "reverse-image",
      "image-search"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 76,
    "name": "Google Images",
    "url": "https://images.google.com/",
    "parentCategory": "osint",
    "childCategory": "image-investigation",
    "description": "Widely used reverse image search tool with powerful visual recognition.",
    "tags": [
      "reverse-image",
      "google",
      "visual-search"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 77,
    "name": "ExifData",
    "url": "http://exifdata.com/",
    "parentCategory": "digital-forensics",
    "childCategory": "metadata-analysis",
    "description": "Online EXIF viewer to extract camera settings, dates, and GPS coordinates from images.",
    "tags": [
      "metadata",
      "exif",
      "forensics"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 78,
    "name": "Lullar",
    "url": "http://com.lullar.com",
    "parentCategory": "osint",
    "childCategory": "email-investigation",
    "description": "People search by email that checks multiple social networking sites simultaneously.",
    "tags": [
      "email-search",
      "social-media"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 79,
    "name": "EmailFinder",
    "url": "http://www.emailfinder.com",
    "parentCategory": "osint",
    "childCategory": "email-investigation",
    "description": "Tool for locating verified email addresses associated with names and companies.",
    "tags": [
      "email-lookup",
      "contact-info"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 80,
    "name": "EmailChange",
    "url": "http://emailchange.com/",
    "parentCategory": "osint",
    "childCategory": "email-investigation",
    "description": "Search tool to find updated email addresses for individuals who have moved providers.",
    "tags": [
      "email-tracking",
      "updates"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 81,
    "name": "Criminal Searches",
    "url": "http://www.criminalsearches.com",
    "parentCategory": "osint",
    "childCategory": "public-records",
    "description": "Search public criminal records, including sex offender registries and court records.",
    "tags": [
      "criminal-records",
      "public-records",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 82,
    "name": "USA Trace",
    "url": "http://www.usatrace.com",
    "parentCategory": "osint",
    "childCategory": "public-records",
    "description": "Professional-grade background checks and SSN verification services.",
    "tags": [
      "background-check",
      "ssn",
      "usa"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 83,
    "name": "GPS Coordinates",
    "url": "http://www.gps-coordinates.net/",
    "parentCategory": "osint",
    "childCategory": "geolocation",
    "description": "Identify exact latitude and longitude or convert addresses to coordinates.",
    "tags": [
      "maps",
      "geolocation",
      "coordinates"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 84,
    "name": "DB-IP",
    "url": "http://db-ip.com/",
    "parentCategory": "network-security",
    "childCategory": "ip-analysis",
    "description": "Comprehensive IP address intelligence and geolocation database API.",
    "tags": [
      "ip-analysis",
      "geolocation",
      "network"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 85,
    "name": "IP Location",
    "url": "https://www.iplocation.net/",
    "parentCategory": "network-security",
    "childCategory": "ip-analysis",
    "description": "Compare geolocation results from multiple IP database providers simultaneously.",
    "tags": [
      "ip-lookup",
      "geolocation",
      "isp-data"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 86,
    "name": "Whois.net",
    "url": "https://www.whois.net",
    "parentCategory": "osint",
    "childCategory": "domain-investigation",
    "description": "Standard service for looking up domain registration and ownership data.",
    "tags": [
      "whois",
      "domain",
      "registration"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 87,
    "name": "IP-Tracker",
    "url": "http://www.ip-tracker.org",
    "parentCategory": "network-security",
    "childCategory": "ip-analysis",
    "description": "Detailed IP tracking tool providing location, ISP, and host details.",
    "tags": [
      "ip-tracker",
      "network",
      "recon"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 88,
    "name": "Monitter",
    "url": "http://monitter.com/",
    "parentCategory": "osint",
    "childCategory": "social-media",
    "description": "Real-time Twitter monitor that allows you to track keywords in specific geographic locations.",
    "tags": [
      "social-media",
      "real-time",
      "twitter"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 89,
    "name": "Social Mention",
    "url": "http://socialmention.com/",
    "parentCategory": "osint",
    "childCategory": "social-media",
    "description": "Real-time social media search and analysis engine for brand and user tracking.",
    "tags": [
      "social-media",
      "sentiment",
      "monitoring"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 90,
    "name": "Whostalkin",
    "url": "http://www.whostalkin.com/",
    "parentCategory": "osint",
    "childCategory": "social-media",
    "description": "Social media search tool that aggregates mentions across blogs, news, and networks.",
    "tags": [
      "social-media",
      "search",
      "aggregator"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 91,
    "name": "Have I Been Pwned",
    "url": "https://haveibeenpwned.com/",
    "parentCategory": "osint",
    "childCategory": "breach-data",
    "description": "The industry standard for checking if accounts or phone numbers have been leaked in data breaches.",
    "tags": [
      "breach-data",
      "passwords",
      "leaks"
    ],
    "isPinned": true,
    "isStarred": true,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 92,
    "name": "HashKiller",
    "url": "https://hashkiller.co.uk/",
    "parentCategory": "malware-analysis",
    "childCategory": "hash-lookup",
    "description": "Database for cracking and identifying MD5 and SHA1 hashes.",
    "tags": [
      "hashes",
      "cracking",
      "decryption"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 93,
    "name": "BreachAlarm",
    "url": "https://breachalarm.com/",
    "parentCategory": "osint",
    "childCategory": "breach-data",
    "description": "Anonymous breach checker that notifies you if your email appears in new data dumps.",
    "tags": [
      "breach-data",
      "email-security"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
  {
    "id": 94,
    "name": "GeoImgr",
    "url": "http://geoimgr.com/",
    "parentCategory": "osint",
    "childCategory": "geolocation",
    "description": "Tool to view and edit geographic metadata (EXIF) in photos.",
    "tags": [
      "metadata",
      "geotag",
      "images"
    ],
    "isPinned": false,
    "isStarred": false,
    "dateAdded": "2024-12-19"
  },
{
  "id": 95,
  "name": "Prowler",
  "url": "https://github.com/prowler-cloud/prowler",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Open-source multi-cloud security assessment for AWS, Azure, GCP and Kubernetes against CIS and other benchmarks.",
  "tags": [
    "aws",
    "azure",
    "gcp",
    "audit",
    "cspm"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 96,
  "name": "ScoutSuite",
  "url": "https://github.com/nccgroup/ScoutSuite",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Multi-cloud security auditing tool; produces an HTML report of misconfigurations across AWS, Azure and GCP.",
  "tags": [
    "aws",
    "azure",
    "gcp",
    "audit"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 97,
  "name": "Pacu",
  "url": "https://github.com/RhinoSecurityLabs/pacu",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Offensive AWS exploitation framework for testing the security posture of an AWS account.",
  "tags": [
    "aws",
    "offensive",
    "privesc"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 98,
  "name": "CloudSploit",
  "url": "https://github.com/aquasecurity/cloudsploit",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Open-source cloud security configuration scanner for AWS, Azure, GCP and Oracle.",
  "tags": [
    "aws",
    "azure",
    "gcp",
    "cspm"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 99,
  "name": "Checkov",
  "url": "https://www.checkov.io",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Static analysis for Terraform, CloudFormation, Kubernetes, ARM and more \u2014 finds misconfigurations in IaC.",
  "tags": [
    "iac",
    "terraform",
    "kubernetes",
    "static"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 100,
  "name": "tfsec",
  "url": "https://github.com/aquasecurity/tfsec",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Static analysis security scanner for Terraform code.",
  "tags": [
    "terraform",
    "iac",
    "static"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 101,
  "name": "Trivy",
  "url": "https://trivy.dev",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Scanner for containers, filesystems and IaC \u2014 vulnerabilities, misconfigurations and secrets.",
  "tags": [
    "containers",
    "iac",
    "vulnerabilities",
    "secrets"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 102,
  "name": "kube-bench",
  "url": "https://github.com/aquasecurity/kube-bench",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Checks whether Kubernetes is deployed securely against the CIS Kubernetes Benchmark.",
  "tags": [
    "kubernetes",
    "cis",
    "audit"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 103,
  "name": "kube-hunter",
  "url": "https://github.com/aquasecurity/kube-hunter",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Hunts for security weaknesses in Kubernetes clusters.",
  "tags": [
    "kubernetes",
    "offensive"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 104,
  "name": "Stratus Red Team",
  "url": "https://github.com/DataDog/stratus-red-team",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Emulates common cloud attack techniques (mapped to MITRE ATT&CK) for detection testing.",
  "tags": [
    "aws",
    "detection",
    "attack-simulation"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 105,
  "name": "CloudMapper",
  "url": "https://github.com/duo-labs/cloudmapper",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Builds diagrams of AWS environments and audits for security issues.",
  "tags": [
    "aws",
    "audit",
    "visualisation"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
},
{
  "id": 106,
  "name": "Cartography",
  "url": "https://github.com/lyft/cartography",
  "parentCategory": "network-security",
  "childCategory": "cloud-security",
  "description": "Maps cloud and infrastructure assets and their relationships into a graph for analysis.",
  "tags": [
    "aws",
    "gcp",
    "graph",
    "asset-inventory"
  ],
  "isPinned": false,
  "isStarred": false,
  "dateAdded": "2026-10-25"
}
];
