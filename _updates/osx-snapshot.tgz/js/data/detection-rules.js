/* Default Sigma and YARA rules.
   Plain JSON after the "=" — edit it like a .json file. Loaded as a script so the app also works from file://. */
const RULE_SEED = [
  {
    "id": "sig-2026-001",
    "type": "sigma",
    "title": "Suspicious Explorer Process with Whitespace Padding",
    "description": "Detects a known 2025/2026 technique (ClickFix/FileFix) where 'explorer.exe' is launched with extra spaces to evade simple command-line filters.",
    "code": "logsource:\n    category: process_creation\n    product: windows\ndetection:\n    selection:\n        Image|endswith: '\\explorer.exe'\n        CommandLine|contains: '   '\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "malware",
    "technique": "T1059",
    "author": "SigmaHQ",
    "platform": "Windows",
    "tags": [
      "clickfix",
      "evasion",
      "lotl"
    ],
    "references": [],
    "created": "2026-01-10T00:00:00Z",
    "modified": "2026-01-10T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-001",
    "type": "yara",
    "title": "2026 AI-Generated Phishing HTML",
    "description": "Detects structural patterns common in high-fidelity phishing kits seen in early 2026 that use AI to bypass standard keyword filters.",
    "code": "rule AI_Phish_Kit_2026 {\n    meta:\n        description = \"Detects advanced 2026 phishing structures\"\n        author = \"ThreatNet Ops\"\n    strings:\n        $obf1 = /<script>eval\\(atob\\(['\"]/ \n        $css1 = \"display: none; visibility: hidden;\" \n        $hook = \"rest/v1/auth/login\"\n    condition:\n        2 of them\n}",
    "severity": "critical",
    "category": "malware",
    "technique": "T1566.002",
    "author": "Community",
    "platform": "Web",
    "tags": [
      "phishing",
      "ai-social-engineering"
    ],
    "references": [],
    "created": "2026-01-20T00:00:00Z",
    "modified": "2026-01-20T00:00:00Z",
    "starred": true
  },
  {
    "id": "sig-2026-002",
    "type": "sigma",
    "title": "Kerberoasting via RC4 TGS Floods",
    "description": "Detects Silent Kerberoasting attempts using weak RC4 encryption.",
    "code": "logsource:\n    product: windows\n    service: security\ndetection:\n    selection:\n        EventID: 4769\n        TicketOptions: '0x40810000'\n        TicketEncryptionType: '0x17'\n    condition: selection\nlevel: medium",
    "severity": "medium",
    "category": "credential-access",
    "technique": "T1558.003",
    "author": "SEC4U",
    "platform": "Active Directory",
    "tags": [
      "kerberos",
      "lateral-movement"
    ],
    "references": [],
    "created": "2025-12-22T00:00:00Z",
    "modified": "2025-12-22T00:00:00Z",
    "starred": false
  },
  {
    "id": "sig-2026-003",
    "type": "sigma",
    "title": "Mshta Executing Remote Script",
    "description": "Detects mshta.exe executing remote payloads, a common malware loader technique.",
    "code": "logsource:\n    category: process_creation\n    product: windows\ndetection:\n    selection:\n        Image|endswith: '\\mshta.exe'\n        CommandLine|contains:\n            - 'http'\n            - 'https'\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "malware",
    "technique": "T1218.005",
    "author": "ThreatNet Ops",
    "platform": "Windows",
    "tags": [
      "lolbin",
      "fileless"
    ],
    "references": [],
    "created": "2026-01-18T00:00:00Z",
    "modified": "2026-01-18T00:00:00Z",
    "starred": true
  },
  {
    "id": "sig-2026-004",
    "type": "sigma",
    "title": "PowerShell Encoded Command Execution",
    "description": "Detects PowerShell executions using Base64-encoded commands.",
    "code": "logsource:\n    category: process_creation\n    product: windows\ndetection:\n    selection:\n        Image|endswith: '\\powershell.exe'\n        CommandLine|contains:\n            - '-enc'\n            - '-encodedcommand'\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "malware",
    "technique": "T1059.001",
    "author": "SigmaHQ",
    "platform": "Windows",
    "tags": [
      "powershell",
      "obfuscation"
    ],
    "references": [],
    "created": "2026-01-12T00:00:00Z",
    "modified": "2026-01-12T00:00:00Z",
    "starred": false
  },
  {
    "id": "sig-2026-005",
    "type": "sigma",
    "title": "Cloud Admin API Token Used from New ASN",
    "description": "Detects suspicious cloud admin token usage from new ASNs.",
    "code": "logsource:\n    category: cloud\n    product: generic\ndetection:\n    selection:\n        role: 'admin'\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "apt",
    "technique": "T1550",
    "author": "Community",
    "platform": "Cloud",
    "tags": [
      "cloud",
      "token-abuse"
    ],
    "references": [],
    "created": "2026-01-22T00:00:00Z",
    "modified": "2026-01-22T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-003",
    "type": "yara",
    "title": "Linux Cron Persistence Backdoor",
    "description": "Detects malicious cron jobs used for persistence.",
    "code": "rule Linux_Cron_Backdoor {\n    meta:\n        description = \"Detects cron-based persistence backdoors\"\n        author = \"Community\"\n    strings:\n        $cron1 = \"* * * * *\" \n        $curl = \"curl -s\" nocase\n        $wget = \"wget -q\" nocase\n        $pipe = \"| sh\" nocase\n    condition:\n        2 of them\n}",
    "severity": "critical",
    "category": "persistence",
    "technique": "T1053.003",
    "author": "Community",
    "platform": "Linux",
    "tags": [
      "cron",
      "cloud"
    ],
    "references": [],
    "created": "2026-01-19T00:00:00Z",
    "modified": "2026-01-19T00:00:00Z",
    "starred": false
  },
  {
    "id": "sig-2026-ran-001",
    "type": "sigma",
    "title": "Ransomware Pre-Encryption Shadow Copy Deletion",
    "description": "Detects shadow copy deletion commonly executed by ransomware.",
    "code": "logsource:\n    category: process_creation\n    product: windows\ndetection:\n    selection:\n        CommandLine|contains:\n            - 'vssadmin delete shadows'\n            - 'wmic shadowcopy delete'\n            - 'bcdedit /set {default} recoveryenabled no'\n    condition: selection\nlevel: critical",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1490",
    "author": "SigmaHQ",
    "platform": "Windows",
    "tags": [
      "backup-removal"
    ],
    "references": [],
    "created": "2026-01-24T00:00:00Z",
    "modified": "2026-01-24T00:00:00Z",
    "starred": true
  },
  {
    "id": "yar-2026-ran-002",
    "type": "yara",
    "title": "Linux Ransomware ELF Payload",
    "description": "Detects Linux ransomware payloads.",
    "code": "rule Linux_Ransomware_ELF_2026 {\n    meta:\n        description = \"Detects Linux ransomware ELF payloads\"\n        author = \"Community\"\n    strings:\n        $elf = { 7F 45 4C 46 }\n        $note = \"YOUR FILES HAVE BEEN ENCRYPTED\" nocase\n    condition:\n        $elf and $note\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "Community",
    "platform": "Linux",
    "tags": [
      "linux"
    ],
    "references": [],
    "created": "2026-01-24T00:00:00Z",
    "modified": "2026-01-24T00:00:00Z",
    "starred": false
  },
  {
    "id": "sig-2026-ran-010",
    "type": "sigma",
    "title": "Ransomware Shadow Copy and Recovery Deletion",
    "description": "Detects commands commonly executed by ransomware to remove backups and disable recovery before encryption.",
    "code": "logsource:\n    category: process_creation\n    product: windows\ndetection:\n    selection:\n        CommandLine|contains:\n            - 'vssadmin delete shadows'\n            - 'wmic shadowcopy delete'\n            - 'bcdedit /set {default} recoveryenabled no'\n            - 'bcdedit /set {default} bootstatuspolicy ignoreallfailures'\n    condition: selection\nlevel: critical",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1490",
    "author": "SigmaHQ",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "backup-destruction"
    ],
    "references": [],
    "created": "2026-01-25T00:00:00Z",
    "modified": "2026-01-25T00:00:00Z",
    "starred": true
  },
  {
    "id": "sig-2026-ran-011",
    "type": "sigma",
    "title": "Linux and ESXi Ransomware VM Termination",
    "description": "Detects ESXi-focused ransomware stopping virtual machines prior to encryption.",
    "code": "logsource:\n    category: process_creation\n    product: linux\ndetection:\n    selection:\n        CommandLine|contains:\n            - 'esxcli vm process kill'\n            - 'vim-cmd vmsvc/power.off'\n    condition: selection\nlevel: critical",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1489",
    "author": "Community",
    "platform": "Linux",
    "tags": [
      "ransomware",
      "esxi"
    ],
    "references": [],
    "created": "2026-01-25T00:00:00Z",
    "modified": "2026-01-25T00:00:00Z",
    "starred": true
  },
  {
    "id": "sig-2026-mal-010",
    "type": "sigma",
    "title": "PowerShell Encoded Malware Execution",
    "description": "Detects obfuscated PowerShell execution commonly used by modern malware loaders.",
    "code": "logsource:\n    category: process_creation\n    product: windows\ndetection:\n    selection:\n        Image|endswith: '\\powershell.exe'\n        CommandLine|contains:\n            - '-enc'\n            - '-encodedcommand'\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "malware",
    "technique": "T1059.001",
    "author": "SigmaHQ",
    "platform": "Windows",
    "tags": [
      "malware",
      "loader",
      "obfuscation"
    ],
    "references": [],
    "created": "2026-01-25T00:00:00Z",
    "modified": "2026-01-25T00:00:00Z",
    "starred": false
  },
  {
    "id": "sig-2026-cred-010",
    "type": "sigma",
    "title": "LSASS Credential Dump Attempt",
    "description": "A process outside the Windows and Program Files folders opens LSASS memory with the access rights credential dumpers use (for example Mimikatz, procdump or comsvcs MiniDump). Normal system processes reading LSASS are excluded.",
    "code": "title: LSASS Credential Dump Attempt\nstatus: stable\ndescription: A process outside the Windows and Program Files folders opens LSASS with the access rights credential dumpers need.\nlogsource:\n    category: process_access\n    product: windows\ndetection:\n    selection:\n        TargetImage|endswith: '\\lsass.exe'\n        GrantedAccess|endswith:\n            - '1010'\n            - '1410'\n            - '1438'\n            - '143a'\n            - '1f3fff'\n            - '1fffff'\n    filter_system:\n        SourceImage|startswith:\n            - 'C:\\Windows\\System32\\'\n            - 'C:\\Windows\\SysWOW64\\'\n            - 'C:\\Program Files\\'\n            - 'C:\\Program Files (x86)\\'\n            - 'C:\\ProgramData\\Microsoft\\Windows Defender\\'\n    condition: selection and not filter_system\nfalsepositives:\n    - Security and monitoring agents installed outside Program Files\n    - Admin tools such as Process Explorer or Procmon run from a user folder\nlevel: high",
    "severity": "high",
    "category": "credential-access",
    "technique": "T1003.001",
    "author": "SigmaHQ",
    "platform": "Windows",
    "tags": [
      "credentials",
      "lsass"
    ],
    "references": [],
    "created": "2026-01-25T00:00:00Z",
    "modified": "2026-11-03T00:00:00Z",
    "starred": true,
    "replaces": [
      "logsource:\n    category: process_access\n    product: windows\ndetection:\n    selection:\n        TargetImage|endswith: '\\lsass.exe'\n    condition: selection\nlevel: high"
    ]
  },
  {
    "id": "sig-2026-lat-010",
    "type": "sigma",
    "title": "Suspicious PsExec Lateral Movement",
    "description": "Detects use of PsExec for lateral movement, commonly seen in ransomware intrusions.",
    "code": "logsource:\n    category: process_creation\n    product: windows\ndetection:\n    selection:\n        Image|endswith: '\\psexec.exe'\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "lateral-movement",
    "technique": "T1569.002",
    "author": "Community",
    "platform": "Windows",
    "tags": [
      "lateral-movement",
      "ransomware"
    ],
    "references": [],
    "created": "2026-01-25T00:00:00Z",
    "modified": "2026-01-25T00:00:00Z",
    "starred": false
  },
  {
    "id": "sig-2026-pers-010",
    "type": "sigma",
    "title": "Registry Run Key Persistence",
    "description": "Detects malware establishing persistence via Windows Run registry keys.",
    "code": "logsource:\n    category: registry_event\n    product: windows\ndetection:\n    selection:\n        TargetObject|contains: 'CurrentVersion\\\\Run'\n    condition: selection\nlevel: medium",
    "severity": "medium",
    "category": "persistence",
    "technique": "T1547.001",
    "author": "SigmaHQ",
    "platform": "Windows",
    "tags": [
      "persistence",
      "autorun"
    ],
    "references": [],
    "created": "2026-01-25T00:00:00Z",
    "modified": "2026-01-25T00:00:00Z",
    "starred": false
  },
  {
    "id": "sig-2026-exf-010",
    "type": "sigma",
    "title": "Suspicious Data Exfiltration via Curl",
    "description": "Detects potential data exfiltration using curl to external servers.",
    "code": "logsource:\n    category: process_creation\n    product: linux\ndetection:\n    selection:\n        Image|endswith: '/curl'\n        CommandLine|contains:\n            - '-X POST'\n            - '--data'\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "exfiltration",
    "technique": "T1041",
    "author": "Community",
    "platform": "Linux",
    "tags": [
      "exfiltration",
      "curl"
    ],
    "references": [],
    "created": "2026-01-25T00:00:00Z",
    "modified": "2026-01-25T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-ran-010",
    "type": "yara",
    "title": "Generic Ransomware Encryption Routine",
    "description": "Detects hybrid AES/RSA encryption logic common across modern ransomware families.",
    "code": "rule Ransomware_Generic_Encrypt_2026 {\n    meta:\n        description = \"Generic ransomware encryption detection\"\n        author = \"ThreatNet Ops\"\n    strings:\n        $aes = \"AES_encrypt\" nocase\n        $rsa = \"RSA_public_encrypt\" nocase\n        $note = \"YOUR FILES HAVE BEEN ENCRYPTED\" nocase\n    condition:\n        2 of them\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "ThreatNet Ops",
    "platform": "Multi",
    "tags": [
      "ransomware",
      "encryption"
    ],
    "references": [],
    "created": "2026-01-25T00:00:00Z",
    "modified": "2026-01-25T00:00:00Z",
    "starred": true
  },
  {
    "id": "yar-2026-mal-010",
    "type": "yara",
    "title": "AI Obfuscated Malware Loader",
    "description": "Detects malware loaders using AI-generated variable entropy and runtime decoding.",
    "code": "rule AI_Malware_Loader_2026 {\n    meta:\n        description = \"AI-assisted malware loader detection\"\n        author = \"ThreatNet Ops\"\n    strings:\n        $entropy = /var [a-zA-Z]{25,40} = \\[/\n        $decode = \"String.fromCharCode\" nocase\n        $eval = \"eval(\" nocase\n    condition:\n        filesize < 400KB and 2 of them\n}",
    "severity": "high",
    "category": "malware",
    "technique": "T1059",
    "author": "ThreatNet Ops",
    "platform": "Web",
    "tags": [
      "malware",
      "ai-obfuscation"
    ],
    "references": [],
    "created": "2026-01-25T00:00:00Z",
    "modified": "2026-01-25T00:00:00Z",
    "starred": true
  },
  {
    "id": "yar-2026-ailock-001",
    "type": "yara",
    "title": "AiLock Ransomware Detection",
    "description": "Detection rule for AiLock Ransomware using file markers and distinctive strings.",
    "code": "rule CyberCrime_AiLock_AiLockRansomware {\n    meta:\n        description = \"Detection rule for AiLock Ransomware\"\n        author = \"gmrdkd@s2w.inc\"\n        created_at = \"2025-04-03\"\n        version = \"v1.0\"\n        threat_actor = \"AiLock\"\n        category = \"Malware\"\n        malware_name = \"AiLock Ransomware\"\n        severity = \"High\"\n        hash1 = \"2a728d98ae8280efeaa674783181f3fa\"\n    strings:\n        $string1 = \".AiLock\" ascii wide nocase\n        $string2 = \"Start Log:%d Network:%d Selfdelete:%d Path=%s\" ascii wide nocase\n        $string3 = \"Total time of encryption: %llu seconds\" ascii wide nocase\n        $string4 = \"read=%u kbytes, write=%u kbytes, opened=%u, encPS=%u, totalFound=%u, TotalEncrypted=%u\" ascii wide nocase\n        $string5 = \"Single instance only Exit\" ascii wide nocase\n        $marker1 = {BE BA AD AB}\n        $marker2 = {B5 00 6B B1}\n        $marker3 = {00 B5 B1 6B}\n        $marker4 = {DE AD BA BE}\n        $marker5 = {BA BE DE AD}\n    condition:\n        uint16(0) == 0x5A4D\n        and all of ($marker*)\n        and 2 of ($string*)\n}",
    "severity": "high",
    "category": "ransomware",
    "technique": "T1486",
    "author": "gmrdkd@s2w.inc",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "ailock"
    ],
    "references": [],
    "created": "2025-04-03T00:00:00Z",
    "modified": "2025-04-03T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-akira-001",
    "type": "yara",
    "title": "Akira Ransomware Windows Payload",
    "description": "Detects Akira ransomware Windows payload through characteristic strings and patterns.",
    "code": "rule Akira {\n    meta:\n        author = \"rivitna\"\n        family = \"ransomware.akira.windows\"\n        description = \"Akira ransomware Windows payload\"\n        severity = 10\n        score = 100\n    strings:\n        $s0 = \"\\x00--encryption_path\\x00\" ascii wide\n        $s1 = \"\\x00--share_file\\x00\" ascii wide\n        $s2 = \"\\x00--encryption_percent\\x00\" ascii wide\n        $s3 = \"\\x00-fork\\x00\" ascii\n        $s4 = \"\\x00-localonly\\x00\" ascii wide\n        $s5 = \"\\x00Failed to read share files\\x00\" ascii wide\n        $s6 = \":\\\\akira\\\\asio\\\\include\\\\\" ascii\n        $s7 = \"\\x00write_encrypt_info error: \\x00\" ascii\n        $s8 = \"\\x00encrypt_part error: \\x00\" ascii\n        $s9 = \"\\x00Detected number of cpus = \\x00\" ascii\n        $s10 = \"\\x00No path to encrypt\\x00\" ascii\n        $s11 = \"Paste this link - https://akira\" ascii\n        $s12 = \"\\x00Trend Micro\\x00\" wide\n        $s13 = \"Failed to make full encrypt\" ascii wide\n        $s14 = \"Failed to make spot encrypt\" ascii wide\n        $s15 = \"Failed to make part encrypt\" ascii wide\n        $s16 = \"Failed to write header\" ascii wide\n        $s17 = \"file rename failed. System error:\" ascii wide\n        $s18 = \"Number of thread to folder parsers = \\x00\" ascii\n        $s19 = \"Number of threads to encrypt = \\x00\" ascii\n        $s20 = \"Number of thread to root folder parsers = \\x00\" ascii\n        $s21 = \"Failed to read share files!\\x00\" ascii\n    condition:\n        uint16(0) == 0x5A4D and 7 of ($s*)\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "rivitna",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "akira"
    ],
    "references": [],
    "created": "2026-01-26T00:00:00Z",
    "modified": "2026-01-26T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-blackcat-001",
    "type": "yara",
    "title": "BlackCat Ransomware Windows Detection",
    "description": "Detects the BlackCat (ALPHV) ransomware Windows version using characteristic strings.",
    "code": "rule ransomware_win_blackcat {\n    meta:\n        id = \"873355f7-3942-4171-9df7-f524bb6b6903\"\n        description = \"Detect the BlackCat ransomware (Windows version)\"\n        author = \"Sekoia.io\"\n        creation_date = \"2022-01-19\"\n        classification = \"TLP:CLEAR\"\n        version = \"1.1\"\n    strings:\n        $s1 = \"desktop_image::set_desktop_wallpaper=\" ascii\n        $s2 = \"C:\\\\Users\\\\Public\\\\All Usersdeploy_note_and_image_for_all_users=\" ascii\n        $s3 = \"propagate::none\" ascii\n        $s4 = \"propagate::failed=\" ascii\n        $s5 = \"propagate::ok=\" ascii\n        $s6 = \"query_status_process::ok=\" ascii\n        $s7 = \"enum_dependent_services::ok=\" ascii\n        $s8 = \"enum_dependent_services::error=\" ascii\n        $s9 = \"try_stop=\" ascii\n        $s10 = \"try_stop::ok=\" ascii\n        $s11 = \"try_stop::failed=\" ascii\n        $s12 = \"stop=\" ascii\n        $s13 = \"dependent_service_name=\" ascii\n        $s14 = \"kill_all=\" ascii\n        $s15 = \"detach=\" ascii\n    condition:\n        uint16(0)==0x5A4D\n        and filesize > 2MB and filesize < 4MB\n        and all of them\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "Sekoia.io",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "blackcat",
      "alphv"
    ],
    "references": [
      "https://www.sekoia.io"
    ],
    "created": "2022-01-19T00:00:00Z",
    "modified": "2022-01-19T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-avoslocker-001",
    "type": "yara",
    "title": "AvosLocker Ransomware Detection",
    "description": "Detects AvosLocker ransomware through cryptopp library references.",
    "code": "rule ransomware_win_avoslocker {\n    meta:\n        id = \"fc5c2483-48cb-4282-b6cb-ac728b948607\"\n        version = \"1.0\"\n        description = \"Detect AvosLocker ransomware (2021-07)\"\n        author = \"Sekoia.io\"\n        creation_date = \"2021-08-03\"\n        classification = \"TLP:CLEAR\"\n        hash6 = \"f810deb1ba171cea5b595c6d3f816127fb182833f7a08a98de93226d4f6a336f\"\n        hash7 = \"c0a42741eef72991d9d0ee8b6c0531fc19151457a8b59bdcf7b6373d1fe56e02\"\n        hash8 = \"84d94c032543e8797a514323b0b8fd8bd69b4183f17351628b13d1464093af2d\"\n    strings:\n        $s1 = \"cryptopp850\\\\rijndael_simd.cpp\" ascii\n        $s2 = \"cryptopp850\\\\sha_simd.cpp\" ascii\n        $s3 = \"cryptopp850\\\\gf2n_simd.cpp\" ascii\n        $s4 = \"cryptopp850\\\\sse_simd.cpp\" ascii\n    condition:\n        all of them\n        and uint16(0)==0x5A4D\n        and filesize > 900KB\n        and filesize < 950KB\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "Sekoia.io",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "avoslocker"
    ],
    "references": [],
    "created": "2021-08-03T00:00:00Z",
    "modified": "2021-08-03T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-babuk-esxi-001",
    "type": "yara",
    "title": "Babuk ESXi Ransomware",
    "description": "Detects Babuk ransomware targeting ESXi environments.",
    "code": "rule Babuk_ESXi {\n    meta:\n        author = \"rivitna\"\n        family = \"ransomware.babuk.esxi\"\n        description = \"Babuk ESXi\"\n        severity = 10\n        score = 100\n    strings:\n        $h0 = \"/dev/urandom\\x00\" ascii\n        $h1 = \"EiB\\x00PiB\\x00TiB\\x00GiB\\x00MiB\\x00KiB\\x00B\\x00\" ascii\n        $h2 = \"crypting: %s\\n\\x00\" ascii\n        $c0 = { 67 E6 09 6A [2-8] 85 AE 67 BB [2-8] 72 F3 6E 3C [2-8]\n                3A F5 4F A5 [2-8] 7F 52 0E 51 [2-8] 8C 68 05 9B }\n        $c1 = { 98 2F 8A 42 91 44 37 71 CF FB C0 B5 A5 DB B5 E9\n                5B C2 56 39 F1 11 F1 59 A4 82 3F 92 D5 5E 1C AB }\n        $c2 = { 79 37 9E 89 [4-16] C1 C? ( 15 | 0B ) [16-40] 79 37 9E 89 }\n    condition:\n        (uint32(0) == 0x464C457F) and (filesize < 120000) and\n        (all of ($c*)) and (1 of ($h*))\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "rivitna",
    "platform": "Linux",
    "tags": [
      "ransomware",
      "babuk",
      "esxi"
    ],
    "references": [],
    "created": "2026-01-26T00:00:00Z",
    "modified": "2026-01-26T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-babuk-v3-001",
    "type": "yara",
    "title": "Babuk Ransomware v3",
    "description": "Detects Babuk Ransomware version 3 through characteristic strings and parameters.",
    "code": "rule BabukRansomwareV3 {\n    meta:\n        description = \"YARA rule for Babuk Ransomware v3\"\n        reference = \"http://chuongdong.com/reverse engineering/2021/01/16/BabukRansomware-v3/\"\n        author = \"@cPeterr\"\n        date = \"2021-01-16\"\n        rule_version = \"v3\"\n        malware_type = \"ransomware\"\n        tlp = \"white\"\n    strings:\n        $lanstr1 = \"-lanfirst\"\n        $lanstr2 = \"-nolan\"\n        $lanstr3 = \"shares\"\n        $str1 = \"BABUK LOCKER\"\n        $str2 = \"babukq4e2p4wu4iq.onion\"\n        $str3 = \"How To Restore Your Files.txt\" wide\n        $str4 = \"babuk_v3\"\n        $str5 = \".babyk\" wide\n    condition:\n        all of ($str*) and all of ($lanstr*)\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "@cPeterr",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "babuk"
    ],
    "references": [
      "http://chuongdong.com/reverse engineering/2021/01/16/BabukRansomware-v3/"
    ],
    "created": "2021-01-16T00:00:00Z",
    "modified": "2021-01-16T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-beast-001",
    "type": "yara",
    "title": "Beast Ransomware Windows",
    "description": "Detects Beast ransomware Windows payload through hex patterns.",
    "code": "rule Beast {\n    meta:\n        author = \"rivitna\"\n        family = \"ransomware.beast\"\n        description = \"Beast ransomware Windows payload\"\n        severity = 10\n        score = 100\n    strings:\n        $h0 = { 6A 00 56 68 ?? ?? 00 00 57 6A 19 68 AA 00 00 00 6A ??\n                6A 0A 68 00 10 00 50 50 }\n        $h1 = { 6A 00 56 68 ?? ?? 00 00 57 6A 19 68 AA 00 00 00\n                68 ?? 00 00 00 6A 0A 68 00 10 00 50 50 }\n        $h2 = { 81 BC 24 ?? 00 00 00 50 4B 06 06 75 6?\n                81 BC 24 ?? 00 00 00 50 4B 06 07 75 5?\n                81 BC 24 ?? 00 00 00 50 4B 05 06 75 }\n        $h3 = { C7 44 24 ?? 17 10 14 06 }\n        $h4 = { 40 04 19 08 C7 45 ?? 19 04 23 04 C7 45 ?? 3F 04 40 04\n                C7 45 ?? 28 04 42 04 C7 45 ?? 43 08 22 04 }\n    condition:\n        uint16(0) == 0x5A4D and 3 of ($h*)\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "rivitna",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "beast"
    ],
    "references": [],
    "created": "2026-01-26T00:00:00Z",
    "modified": "2026-01-26T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-blackbyte-001",
    "type": "yara",
    "title": "BlackByte Ransomware",
    "description": "Detects BlackByte ransomware through Go-based string patterns.",
    "code": "rule BlackByte {\n    meta:\n        author = \"rivitna\"\n        family = \"ransomware.hive\"\n        description = \"BlackByte ransomware Windows payload\"\n        severity = 10\n        score = 100\n    strings:\n        $h0 = { 83 E? 05 48 83 C? 01 88 4? FF 4? 39 ?? (74 | 75) ?? }\n        $s0 = \"\\x00main.RSA\\x00\" ascii\n        $s1 = \"\\x00main._Cfunc_Begin\\x00\" ascii\n        $s2 = \"\\x00main._Cfunc_Inj\\x00\" ascii\n        $s3 = \"\\x00main.Inja\" ascii\n        $s4 = \"\\x00main.SetWinVer\\x00\" ascii\n        $s5 = \"\\x00main.DelShadows\" ascii\n        $s6 = \"\\x00main.StartNetworkS\" ascii\n        $s7 = \"\\x00main.EnableLink\" ascii\n        $s8 = \"\\x00main.EnableLongPaths\" ascii\n        $s9 = \"\\x00main.GrantAll\" ascii\n        $s10 = \"\\x00main.LanScan\" ascii\n        $s11 = \"\\x00main.SetupKey\\x00\" ascii\n        $s12 = \"\\x00main.PbKey\\x00\" ascii\n        $s13 = \"\\x00main.Pognali\" ascii\n        $s14 = \"\\x00main.ShowNote\" ascii\n        $s15 = \"\\x00main.MountDrives\" ascii\n        $s16 = \"\\x00main.StopAllsvc\" ascii\n        $s17 = \"\\x00main.GenDrives\" ascii\n        $s18 = \"\\x00main.ParsePC\" ascii\n        $s19 = \"\\x00main.GetAccess\" ascii\n        $s20 = \"\\x00main.KillHypers\" ascii\n        $s21 = \"\\x00main.ParseHypers\" ascii\n        $s22 = \"\\x00main.Aes256Encr\\x00\" ascii\n        $s23 = \"\\x00main.Aes256Decr\\x00\" ascii\n    condition:\n        uint16(0) == 0x5A4D and (1 of ($h*) or 4 of ($s*))\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "rivitna",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "blackbyte"
    ],
    "references": [],
    "created": "2026-01-26T00:00:00Z",
    "modified": "2026-01-26T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-conti-001",
    "type": "yara",
    "title": "Conti Ransomware v2/v3",
    "description": "Detects Conti ransomware versions 2 and 3 through hex patterns.",
    "code": "rule Conti {\n    meta:\n        author = \"rivitna\"\n        family = \"ransomware.conti.windows\"\n        description = \"Conti 2 and 3 ransomware Windows payload\"\n        severity = 10\n        score = 100\n    strings:\n        $h0 = { 85 ?? 0F 84 ?? 0? 00 00 ( 0F B6 00 | 8A 0? ) 3C E9 74 1?\n                3C FF 0F 85 ?? 0? 00 00 80 7? 01 25 0F 85 }\n        $h1 = { 45 33 C9 C7 44 24 ?? 0C 02 00 00 [0-4] 33 D2 48 89 [8-12]\n                45 8D 41 01 FF D0 85 C0 }\n        $h2 = { 83 C4 08 8D 4D ?? 68 0C 02 00 00 5? 5? 6A 00 6A 01 6A 00\n                FF 75 ?? FF D0 }\n        $h3 = { ( 2D 5B 00 00 | DA FC 01 B8 ) ( 41 83 | 83 ) F? 04 7C ??\n                [12-24] 69 0? 95 E9 D1 5B ( 48 83 | 83 ) C2 04\n                ( 45 69 | 69 ) ?? 95 E9 D1 5B }\n    condition:\n        uint16(0) == 0x5A4D and 2 of ($h*)\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "rivitna",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "conti"
    ],
    "references": [],
    "created": "2026-01-26T00:00:00Z",
    "modified": "2026-01-26T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-darkside-linux-001",
    "type": "yara",
    "title": "DarkSide Ransomware Linux",
    "description": "Detects DarkSide ransomware Linux version.",
    "code": "rule Darkside_linux {\n    meta:\n        description = \"darkside ransomware linux version\"\n        author = \"Alienvault Labs\"\n        copyright = \"Alienvault Inc. 2021\"\n    strings:\n        $s1 = \"[END] Remove Self\"\n        $s2 = \"[CFG] Landing URL#[\"\n        $s3 = \"Welcome to DarkSide\"\n        $dec_loop = { 0F B6 02 84 C0 74 1C 0F B6 B1 DF A7 89 00 40 38 F0 74 10 48 83 C1 01 31 F0 48 83 F9 20 88 02 49 0F 44 C8 }\n    condition:\n        uint32(0) == 0x464C457F and all of them\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "Alienvault Labs",
    "platform": "Linux",
    "tags": [
      "ransomware",
      "darkside"
    ],
    "references": [],
    "created": "2021-05-10T00:00:00Z",
    "modified": "2021-05-10T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-qilin-loader-001",
    "type": "yara",
    "title": "Qilin Ransomware Loader",
    "description": "Detects Qilin ransomware Windows loader with large .rdata section.",
    "code": "import \"pe\"\nrule Qilin_Loader {\n    meta:\n        author = \"rivitna\"\n        family = \"ransomware.qilin.windows\"\n        description = \"Qilin ransomware Windows loader\"\n        severity = 10\n        score = 100\n    strings:\n        $h0 = { 85 C0 75 12 E8 [4] 85 C0 0F 84 ?? 0? 00 00 A3 [4]\n                68 00 ?? ( 2? | 3? | 4? ) 00 6A 00 50 E8 [4] 85 C0\n                0F 84 ?? 0? 00 00 31 D2 BF 00 [2] FF ( BB | 8D ) [0-8]\n                ( 89 44 24 ?? C7 44 24 ?? ?0 ?? ?? 00\n                  C7 44 24 ?? 00 00 00 00 |\n                  ( 89 45 ?? C7 45 ?? ?0 ?? ?? 00 |\n                    C7 45 ?? ?0 ?? ?? 00 89 45 ?? )\n                  C7 45 ?? 00 00 00 00 )\n                EB }\n    condition:\n        uint16(0) == 0x5A4D\n        and for any i in (0..pe.number_of_sections-1):\n        (\n            (pe.sections[i].raw_data_size >= 0x2A0000)\n            and (pe.sections[i].raw_data_size <= 0x500000)\n            and (pe.sections[i].name == \".rdata\")\n        )\n        and 1 of ($h*)\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "rivitna",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "qilin",
      "loader"
    ],
    "references": [],
    "created": "2026-01-26T00:00:00Z",
    "modified": "2026-01-26T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-qilin-esxi-001",
    "type": "yara",
    "title": "Qilin Ransomware ESXi",
    "description": "Detects Qilin ransomware targeting ESXi servers.",
    "code": "rule QilinRansomwareESXi {\n    meta:\n        description = \"rule to detect Qilin Ransomware\"\n        author = \"ShadowStackRe.com\"\n        date = \"2023-12-06\"\n        Rule_Version = \"v1\"\n        malware_type = \"ransomware\"\n        malware_family = \"Qilin\"\n        License = \"MIT License, https://opensource.org/license/mit/\"\n    strings:\n        $strMotd = \"/etc/motd\"\n        $strEncryptQuestion = \"Are you sure to start encryption\"\n        $strConfigStart = \"--- Configuration start ---\"\n        $strEsxiUsage = \"esxcli\"\n        $strEncryptRenameFail = \"Failed to rename encrypted file to\"\n        $strStartJob = \"Started job...\"\n        $strBug = \"\\x1B[%uG 100%%\"\n    condition:\n        all of them\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "ShadowStackRe.com",
    "platform": "Linux",
    "tags": [
      "ransomware",
      "qilin",
      "esxi"
    ],
    "references": [
      "https://opensource.org/license/mit/"
    ],
    "created": "2023-12-06T00:00:00Z",
    "modified": "2023-12-06T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-lockbit3-001",
    "type": "yara",
    "title": "LockBit 3.0 / BlackMatter Ransomware",
    "description": "Detects LockBit 3.0 and BlackMatter ransomware Windows payload.",
    "code": "rule LockBit3 {\n    meta:\n        author = \"rivitna\"\n        family = \"ransomware.lockbit3.windows\"\n        description = \"BlackMatter/LockBit3 ransomware Windows payload\"\n        severity = 10\n        score = 100\n    strings:\n        $h0 = { 64 A1 30 00 00 00 8B B0 A4 00 00 00 8B B8 A8 00 00 00\n                83 FE 05 75 05 83 FF 01 }\n        $h1 = { 02 F1 2A F1 [2-16] D3 CA 03 D0 }\n        $h2 = { 3C 2B 75 04 B0 78 EB 0E 3C 2F 75 04 B0 69 EB 06 3C 3D\n                75 02 B0 7A }\n        $h3 = { 33 C0 40 40 8D 0C C5 01 00 00 00 83 7D 0? 00 75 04 F7 D8\n                EB 0? }\n        $h4 = { C1 C0 09 33 ?8 8D 04 ?? C1 C0 0D 33 ?8 8D 04 ?? C1 C8 0E\n                33 ?8 83 6C 24 ?? 01 }\n        $h5 = { 3D B2 EB AA D4 74 07 3D C0 18 20 01 75 }\n        $h6 = { B9 0D 66 19 00 [0-16] F7 E1 [0-16] 05 5F F3 6E 3C [0-16]\n                25 FF FF FF 07 }\n        $h7 = { 3D 75 BA 0E 64 75 ?? 83 C7 02 66 83 3F 20 74 F7 }\n        $h8 = { 3D 75 80 91 76 74 0E 3D 1B A4 04 00 74 07 3D 9B B4 84 0B 75 }\n    condition:\n        uint16(0) == 0x5A4D and 3 of ($h*)\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "rivitna",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "lockbit",
      "blackmatter"
    ],
    "references": [],
    "created": "2026-01-26T00:00:00Z",
    "modified": "2026-01-26T00:00:00Z",
    "starred": false
  },
  {
    "id": "sig-2026-lockbit-hta-001",
    "type": "sigma",
    "title": "LockBit Metasploit HTA Stager Detection",
    "description": "Detects Metasploit HTA stager used in LockBit campaigns.",
    "code": "logsource:\n    category: file_event\n    product: windows\ndetection:\n    selection:\n        TargetFilename|endswith: '.hta'\n        FileContent|contains:\n            - 'CreateObject(\"Wscript.Shell\")'\n            - 'ExpandEnvironmentStrings(\"%PSModulePath%\")'\n            - 'powershell.exe -nop -w hidden -e'\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "malware",
    "technique": "T1218.005",
    "author": "The DFIR Report",
    "platform": "Windows",
    "tags": [
      "lockbit",
      "metasploit",
      "hta"
    ],
    "references": [
      "https://thedfirreport.com/2025/02/24/confluence-exploit-leads-to-lockbit-ransomware/"
    ],
    "created": "2025-02-20T00:00:00Z",
    "modified": "2025-02-20T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-blackbasta-001",
    "type": "yara",
    "title": "BlackBasta Ransomware",
    "description": "Auto-generated detection for BlackBasta ransomware using code sequences.",
    "code": "rule win_blackbasta_auto {\n    meta:\n        author = \"Felix Bilstein - yara-signator at cocacoding dot com\"\n        date = \"2023-07-11\"\n        version = \"1\"\n        description = \"Detects win.blackbasta.\"\n        info = \"autogenerated rule brought to you by yara-signator\"\n        tool = \"yara-signator v0.6.0\"\n        malpedia_reference = \"https://malpedia.caad.fkie.fraunhofer.de/details/win.blackbasta\"\n        malpedia_license = \"CC BY-SA 4.0\"\n    strings:\n        $sequence_0 = { b8ffffff7f 8bd1 d1ea 2bc2 57 3bc8 7607 }\n        $sequence_1 = { 6800000080 ff15???????? 85c0 754d 837d1c08 8d4d08 }\n    condition:\n        7 of them and filesize < 1758208\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "Felix Bilstein",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "blackbasta"
    ],
    "references": [
      "https://malpedia.caad.fkie.fraunhofer.de/details/win.blackbasta"
    ],
    "created": "2023-07-11T00:00:00Z",
    "modified": "2023-07-11T00:00:00Z",
    "starred": false
  },
  {
    "id": "yar-2026-clop-001",
    "type": "yara",
    "title": "Clop Ransomware",
    "description": "Auto-generated detection for Clop ransomware using code sequences.",
    "code": "rule win_clop_auto {\n    meta:\n        author = \"Felix Bilstein - yara-signator at cocacoding dot com\"\n        date = \"2023-07-11\"\n        version = \"1\"\n        description = \"Detects win.clop.\"\n        info = \"autogenerated rule brought to you by yara-signator\"\n        tool = \"yara-signator v0.6.0\"\n        malpedia_reference = \"https://malpedia.caad.fkie.fraunhofer.de/details/win.clop\"\n        malpedia_license = \"CC BY-SA 4.0\"\n    strings:\n        $sequence_0 = { 6a04 6800300000 6887000000 6a00 }\n        $sequence_1 = { 83c40c 6860070000 6a40 ff15???????? }\n    condition:\n        7 of them and filesize < 796672\n}",
    "severity": "critical",
    "category": "ransomware",
    "technique": "T1486",
    "author": "Felix Bilstein",
    "platform": "Windows",
    "tags": [
      "ransomware",
      "clop"
    ],
    "references": [
      "https://malpedia.caad.fkie.fraunhofer.de/details/win.clop"
    ],
    "created": "2023-07-11T00:00:00Z",
    "modified": "2023-07-11T00:00:00Z",
    "starred": false
  },
  {
    "id": "sig-cloud-001",
    "type": "sigma",
    "title": "CloudTrail logging disabled",
    "description": "CloudTrail StopLogging or DeleteTrail — a classic defence-evasion step after a cloud account compromise.",
    "code": "logsource:\n    product: aws\n    service: cloudtrail\ndetection:\n    selection:\n        eventSource: cloudtrail.amazonaws.com\n        eventName:\n            - StopLogging\n            - DeleteTrail\n            - UpdateTrail\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "threat-intelligence",
    "technique": "T1562.008",
    "author": "OSINTrix",
    "platform": "AWS",
    "tags": [
      "cloud",
      "aws",
      "defense-evasion"
    ],
    "references": [],
    "created": "2026-10-25",
    "modified": "2026-10-25",
    "starred": false
  },
  {
    "id": "sig-cloud-002",
    "type": "sigma",
    "title": "IAM privilege escalation attempt",
    "description": "IAM changes that commonly grant the caller more access: attaching admin policies, new policy versions, access-key creation.",
    "code": "logsource:\n    product: aws\n    service: cloudtrail\ndetection:\n    selection:\n        eventName:\n            - AttachUserPolicy\n            - AttachRolePolicy\n            - PutUserPolicy\n            - PutRolePolicy\n            - CreatePolicyVersion\n            - SetDefaultPolicyVersion\n            - CreateAccessKey\n    condition: selection\nlevel: high",
    "severity": "high",
    "category": "threat-intelligence",
    "technique": "T1098.003",
    "author": "OSINTrix",
    "platform": "AWS",
    "tags": [
      "cloud",
      "aws",
      "privilege-escalation",
      "iam"
    ],
    "references": [],
    "created": "2026-10-25",
    "modified": "2026-10-25",
    "starred": false
  },
  {
    "id": "sig-cloud-003",
    "type": "sigma",
    "title": "S3 bucket made public",
    "description": "Bucket policy or public-access-block changes that can expose an S3 bucket to the internet.",
    "code": "logsource:\n    product: aws\n    service: cloudtrail\ndetection:\n    selection:\n        eventName:\n            - PutBucketPolicy\n            - PutBucketAcl\n            - DeletePublicAccessBlock\n            - PutAccountPublicAccessBlock\n    condition: selection\nlevel: medium",
    "severity": "medium",
    "category": "threat-intelligence",
    "technique": "T1530",
    "author": "OSINTrix",
    "platform": "AWS",
    "tags": [
      "cloud",
      "aws",
      "s3",
      "exposure"
    ],
    "references": [],
    "created": "2026-10-25",
    "modified": "2026-10-25",
    "starred": false
  },
  {
    "id": "sig-cloud-004",
    "type": "sigma",
    "title": "Access from EC2 instance role outside AWS",
    "description": "Temporary instance-role credentials (ASIA...) used from an IP that is not AWS — a sign the IMDS creds were stolen via SSRF and used off-box.",
    "code": "logsource:\n    product: aws\n    service: cloudtrail\ndetection:\n    selection:\n        userIdentity.type: AssumedRole\n        userIdentity.arn|contains: ':assumed-role/'\n    filter:\n        sourceIPAddress|cidr: '10.0.0.0/8'\n    condition: selection and not filter\nlevel: high",
    "severity": "high",
    "category": "threat-intelligence",
    "technique": "T1552.005",
    "author": "OSINTrix",
    "platform": "AWS",
    "tags": [
      "cloud",
      "aws",
      "imds",
      "credential-theft"
    ],
    "references": [],
    "created": "2026-10-25",
    "modified": "2026-10-25",
    "starred": false
  },
  {
    "id": "sig-cloud-005",
    "type": "sigma",
    "title": "Azure role assignment granted",
    "description": "A new Azure RBAC role assignment — watch for Owner/Contributor granted to unexpected principals.",
    "code": "logsource:\n    product: azure\n    service: activitylogs\ndetection:\n    selection:\n        operationName: Microsoft.Authorization/roleAssignments/write\n    condition: selection\nlevel: medium",
    "severity": "medium",
    "category": "threat-intelligence",
    "technique": "T1098.003",
    "author": "OSINTrix",
    "platform": "Azure",
    "tags": [
      "cloud",
      "azure",
      "iam"
    ],
    "references": [],
    "created": "2026-10-25",
    "modified": "2026-10-25",
    "starred": false
  }
];
