/* ==========================================================================
   State, derivation, routing, persistence, shared render helpers.
   ========================================================================== */
const E = Engine, esc = E.esc;
const $ = id => document.getElementById(id);
const STORE_KEY = 'osintrix-poc:v4';
const uid = p => (p || 'x') + '-' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3);
const ico = (n, cls = '') => !LUCIDE[n] ? '' : `<svg class="i ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${LUCIDE[n] || ''}</svg>`;

let DB = null;
const UI = {route:{area:'home'}, q:'', ast:null, sel:null, inspOpen:false, navOpen:false, vcat:'all', vq:'', vview:'grid',
  tcat:'all', tsub:null, tq:'', cloudTab:'guide', cgCat:'all', wnQ:'', wnType:null, padText:null, padSel:null, tlMode:'events', facet:{}, pivot:null, graph:{mode:null, first:null}, entKind:null};

/* ---------- seed ---------- */
function seedDB(){
  const T = Date.parse('2026-09-15T12:00:00Z');
  const recs = DEMO.R.map(([id, caseId, type, t, host, source, title, body, tags]) => ({
    id, caseId, type, tsRaw:t || '', tsZone:t ? 'explicit' : '', ts:t ? E.parseTime(t) : null, host, source, title, body, tags:tags || [],
    ents:E.extract(body), answer:DEMO.answers[id] || '', addedBy:'You', addedAt:t ? E.parseTime(t) + 240000 : Date.parse('2026-09-14T09:40:00Z'), hash:''}));
  const cases = DEMO.cases.map(c => ({...c, created:Date.parse(c.created), updated:Date.parse(c.updated), color:DEMO_CASE_STYLE[c.id][0], icon:DEMO_CASE_STYLE[c.id][1]}));
  const entries = DEMO_ENTRIES.map(([id, caseId, type, fields, x], i) => ({id, caseId, type, fields:{...fields}, priority:x.priority || 'medium', starred:!!x.starred,
    tags:x.tags || [], notes:x.notes || '', src:x.src || '', created:T - i * 3600e3, pos:DEMO_POS[id] ? {x:DEMO_POS[id][0] * .84, y:DEMO_POS[id][1] * .84} : null}));
  const verdicts = {...DEMO.verdicts};
  for(const [id,,,, x] of DEMO_ENTRIES) if(x.verdict){ const e = entries.find(z => z.id === id), k = entryKey(e); if(k) verdicts[k] = x.verdict; else e.verdict = x.verdict; }
  const tools = TOOLS_SEED.map(t => ({id:'t' + t.id, name:t.name, url:t.url, cat:t.parentCategory, sub:t.childCategory, desc:t.description, tags:t.tags || [],
    pinned:!!t.isPinned, starred:!!t.isStarred, added:Date.parse(t.dateAdded) || Date.now(), uses:0, seed:true}));
  return {v:2, cases, records:recs, entries, links:DEMO_LINKS.map(([a, b, label, conf, src], i) => ({id:'l' + i, caseId:entries.find(e => e.id === a).caseId, a, b, label, conf, src})),
    verdicts, tools, feed:DEMO.feed.map(f => ({...f, ts:Date.parse(f.date)})), active:'c-lantern',
    prefs:{theme:'light', size:'m', density:'comfortable', tz:'UTC', navRail:true}, log:[], sample:true};
}
/* A stored workspace is "usable" only if this version understands it. Anything else is kept, never overwritten. */
const usable = d => !!(d && d.v === 2 && Array.isArray(d.entries) && Array.isArray(d.cases) && Array.isArray(d.records));
function readCopy(raw){
  if(raw == null || raw === '') return {state:'empty'};
  let d; try{ d = JSON.parse(raw); }catch(e){ return {state:'bad', why:'it could not be read (the stored data is damaged)', raw}; }
  if(usable(d)) return {state:'ok', d};
  if(d && typeof d.v === 'number' && d.v > 2) return {state:'bad', why:'it was saved by a newer version of OSINTrix', raw, newer:true};
  return {state:'bad', why:'it is not in a format this version understands', raw};
}
function load(){ try{ const c = readCopy(localStorage.getItem(STORE_KEY)); return c.state === 'ok' ? c.d : null; }catch(e){} return null; }
/* IndexedDB is the primary store: far more room than localStorage (~5 MB). localStorage keeps a mirror while it fits. */
const IDB = {db:null,
  open(){ return new Promise(res => { try{ const r = indexedDB.open('osintrix', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => { IDB.db = r.result; res(true); }; r.onerror = () => res(false); r.onblocked = () => res(false); }catch(e){ res(false); } }); },
  get(k){ return new Promise(res => { if(!IDB.db) return res(null); try{ const q = IDB.db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); }catch(e){ res(null); } }); },
  setMany(pairs, dels = []){ return new Promise(res => { if(!IDB.db) return res(false); try{ const tx = IDB.db.transaction('kv', 'readwrite'), st = tx.objectStore('kv'); for(const [k, v] of pairs) st.put(v, k); for(const k of dels) st.delete(k); tx.oncomplete = () => res(true); tx.onerror = tx.onabort = () => res(false); }catch(e){ res(false); } }); },
  set(k, v){ return new Promise(res => { if(!IDB.db) return res(false); try{ const tx = IDB.db.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k); tx.oncomplete = () => res(true); tx.onerror = tx.onabort = () => res(false); }catch(e){ res(false); } }); }};
const STORE = {idb:false, ls:false, persisted:false, bytes:0, quota:0, lastSaved:0};
async function loadAll(){
  STORE.idb = await IDB.open();
  let a = null, envs = [], ca = {state:'empty'}, cb = {state:'empty'};
  if(STORE.idb){ const raw = await IDB.get(STORE_KEY); if(isEnv(raw)) envs.push(raw); else { ca = readCopy(raw); if(ca.state === 'ok'){ a = ca.d; if(a.__rc && !await joinChunks(a)){ ca = {state:'bad', why:'part of it is missing (the stored data is damaged)', raw}; a = null; } } } }
  let lsRaw = null; try{ lsRaw = localStorage.getItem(STORE_KEY); if(isEnv(lsRaw)) envs.push(lsRaw); else cb = readCopy(lsRaw); }catch(e){}
  if(envs.length){ try{ if(navigator.storage && navigator.storage.persisted) STORE.persisted = await navigator.storage.persisted(); }catch(e){} const env = envs.sort((x, y) => (JSON.parse(y).at || 0) - (JSON.parse(x).at || 0))[0]; SEC.locked = true; return {__locked:true, env}; }
  const b = cb.state === 'ok' ? cb.d : null;
  // a copy from a newer version, or no readable copy at all: stop and let the person decide; nothing is written
  const bad = [ca, cb].filter(c => c.state === 'bad');
  if(bad.some(c => c.newer) || (bad.length && !a && !b)) return {__bad:true, copies:bad};
  if(bad.length) await IDB.set(STORE_KEY + ':damaged:' + Date.now(), bad[0].raw);   // the readable copy wins, the other is kept aside
  const pick = a && b ? ((a.savedAt || 0) >= (b.savedAt || 0) ? a : b) : (a || b);
  try{ if(navigator.storage && navigator.storage.persist) STORE.persisted = await navigator.storage.persisted() || await navigator.storage.persist(); }catch(e){}
  return pick;
}
/* Large workspaces store their records in chunks of CHUNK, and a save rewrites only the chunks whose text
   changed. Core + changed chunks go in one IndexedDB transaction, so a save is all-or-nothing. */
const CHUNK = 500, CHUNKED_FROM = 2000, LAST = {chunks:[], n:0};
async function joinChunks(d){
  const n = d.__rc.n, recs = [];
  for(let i = 0; i < n; i++){ const t = await IDB.get(STORE_KEY + ':r:' + i); if(typeof t !== 'string') return false; let part; try{ part = JSON.parse(t); }catch(e){ return false; } if(!Array.isArray(part)) return false; LAST.chunks[i] = t; recs.push(...part); }
  LAST.n = n; d.records = recs; delete d.__rc; return true;
}
function flushChunked(){
  const R = DB.records, n = Math.ceil(R.length / CHUNK), puts = [], dels = [];
  for(let i = 0; i < n; i++){ let t = '['; for(let j = i * CHUNK, e = Math.min(R.length, j + CHUNK); j < e; j++) t += (j > i * CHUNK ? ',' : '') + JSON.stringify(R[j]); t += ']';
    if(LAST.chunks[i] !== t){ puts.push([STORE_KEY + ':r:' + i, t]); LAST.chunks[i] = t; } }
  for(let i = n; i < LAST.n; i++){ dels.push(STORE_KEY + ':r:' + i); delete LAST.chunks[i]; }
  LAST.n = n;
  const core = JSON.stringify(Object.assign({}, DB, {records:[], __rc:{n}}));
  puts.push([STORE_KEY, core]);
  try{ localStorage.removeItem(STORE_KEY); }catch(e){} STORE.ls = false; STORE.bytes = core.length * 2;
  return IDB.setMany(puts, dels).then(r => { if(!r){ LAST.chunks = []; storageOK = false; paintSaved(); } return r; });
}
async function storageEstimate(){ try{ if(navigator.storage && navigator.storage.estimate){ const e = await navigator.storage.estimate(); STORE.quota = e.quota || 0; STORE.usage = e.usage || 0; } }catch(e){} return STORE; }
let saveT = null, storageOK = true;
/* Is every change safely written? changedAt moves on each edit; safeAt moves when a write is confirmed.
   Until they meet, the top bar says "Saving…" and closing or refreshing the tab asks first. */
STORE.gen = 0; STORE.safeGen = 0; STORE.changedAt = 0;
const PENDING = [];   // editors add a check for typing they have not committed yet
const isDirty = () => STORE.gen > STORE.safeGen || PENDING.some(f => { try{ return f(); }catch(e){ return false; } });
let paintT = null;
function markChanged(){ STORE.gen++; STORE.changedAt = Date.now(); clearTimeout(paintT); paintT = setTimeout(paintSaved, 900); }
function markSafe(g){ if(g > STORE.safeGen) STORE.safeGen = g; paintSaved(); }
function save(){ markChanged(); clearTimeout(saveT); saveT = setTimeout(flush, 250); }
/* a finished action (delete, add, restore…) is written at once, not after the typing pause: a refresh or a closed tab
   straight after it must not lose it — a write made while the page is going away can arrive too late for the next page */
function saveSoon(){ markChanged(); clearTimeout(saveT); saveT = setTimeout(flush, 0); }
/* editors with typing still waiting to be committed (the notebook) register here, so every save — including the one on closing the tab — includes it */
const BEFORE_SAVE = [];
function flush(){ clearTimeout(saveT); if(!DB || SEC.locked) return; for(const f of BEFORE_SAVE) try{ f(); }catch(e){ console.error(e); } clearTimeout(saveT); if(!TABS.writer){ paintSaved(); return; } DB.savedAt = Math.max(Date.now(), (DB.savedAt || 0) + 1);   // never a tie between two copies
  const at = DB.savedAt, g = STORE.gen, done = r => { if(r){ STORE.idbAt = Math.max(STORE.idbAt || 0, at); markSafe(g); try{ /* only drop the closing-tab journal if this save already holds every page in it: an older save finishing late must not remove newer typing */ const j = JSON.parse(localStorage.getItem(STORE_KEY + ':nbj') || 'null'); if(j && Array.isArray(j.pages) && j.pages.every(q => (+(q && q.updated) || 0) <= at)) localStorage.removeItem(STORE_KEY + ':nbj'); }catch(e){} } };   // IndexedDB has everything up to 'at'
  if(!SEC.key && STORE.idb && DB.records.length >= CHUNKED_FROM){ storageOK = true; flushChunked().then(done); STORE.lastSaved = Date.now(); paintSaved(); tabSaved(); return; }
  if(LAST.n){ IDB.setMany([], Array.from({length:LAST.n}, (_, i) => STORE_KEY + ':r:' + i)); LAST.n = 0; LAST.chunks = []; }   // back to one piece
  const json = JSON.stringify(DB);
  if(SEC.key) return flushSealed(json).then(() => { if(storageOK) markSafe(g); });
  STORE.bytes = json.length * 2;
  let ok = false; try{ if(json.length < 2400000){ localStorage.setItem(STORE_KEY, json); STORE.ls = true; ok = true; markSafe(g); } else { localStorage.removeItem(STORE_KEY); STORE.ls = false; } }catch(e){ STORE.ls = false; }
  if(STORE.idb){ ok = true; IDB.set(STORE_KEY, json).then(r => { done(r); if(!r && !STORE.ls){ storageOK = false; paintSaved(); } }); }
  storageOK = ok; STORE.lastSaved = Date.now(); paintSaved(); tabSaved(); }
function paintSaved(){ const s = $('saved'); if(s && TABS.writer && storageOK && isDirty() && Date.now() - STORE.changedAt > 800){ s.innerHTML = '<i class="pulse" style="background:var(--text-3)"></i><span>Saving…</span>'; s.title = 'Writing your latest change to this browser'; return; } if(s && !TABS.writer){ s.innerHTML = '<i style="background:var(--amber)"></i><span>Read-only in this tab</span>'; s.title = 'This workspace is open in another tab'; return; } if(s) s.innerHTML = storageOK ? '<i></i><span>Saved in this browser</span>' : '<i style="background:var(--red)"></i><span>Not saved</span>'; s.title = storageOK ? 'Saved in this browser' : 'Not saved — this browser blocks storage'; }
window.addEventListener('pagehide', flush); document.addEventListener('visibilitychange', () => { if(document.visibilityState === 'hidden') flush(); });
let rev = 0, cache = {};
function mutate(what){ rev++; cache = {}; auditAdd(what); DB.log.unshift({at:Date.now(), what}); DB.log.length = Math.min(DB.log.length, 200); saveSoon(); if(typeof onMutate === 'function') onMutate(what); }

/* ---------- lookups ---------- */
const tz = () => DB.prefs.tz || 'UTC';
const theCase = id => DB.cases.find(c => c.id === (id || DB.active)) || null;
function csNewCase(run){ window.__csRun = run;
  openDlg(dhead('New case') + `<form data-form="csNew"><div class="in"><div class="field"><label for="csName">Name</label><input id="csName" required autofocus maxlength="120" placeholder="What are you investigating?"></div>
    <p class="t3 small" style="margin:0">New saves from here go into it; you stay on this page. Scope, colour and the rest can be set on the case later.</p></div>
    <footer><button type="button" class="btn" data-act="dclose">Cancel</button><button class="btn primary">${ico('folder-plus','sm')}Create case</button></footer></form>`);
  setTimeout(() => { const i = $('csName'); if(i) i.focus(); }, 30); }
/* actions that put something into a case, when there is no case at all: offer to make one */
function needCase(){ toast('Make a case first — everything you collect goes into one'); if(typeof caseDlg === 'function') setTimeout(() => caseDlg(), 60); return null; }
/* id → object indexes, rebuilt when the workspace changes (rev) or the array is swapped/grown; a miss falls back to a scan */
const IX = {r:null, rr:-1, rn:0, ra:null, e:null, er:-1, en:0, ea:null};
function recById(id){ if(!id) return null; if(IX.rr !== rev || IX.ra !== DB.records || IX.rn !== DB.records.length){ IX.r = new Map(); for(const r of DB.records) IX.r.set(r.id, r); IX.rr = rev; IX.ra = DB.records; IX.rn = DB.records.length; }
  const x = IX.r.get(id); if(x && x.id === id) return x; return DB.records.find(r => r.id === id) || null; }
function entryById(id){ if(!id) return null; if(IX.er !== rev || IX.ea !== DB.entries || IX.en !== DB.entries.length){ IX.e = new Map(); for(const e of DB.entries) IX.e.set(e.id, e); IX.er = rev; IX.ea = DB.entries; IX.en = DB.entries.length; }
  const x = IX.e.get(id); if(x && x.id === id) return x; return DB.entries.find(e => e.id === id) || null; }
const entKey = e => e.k + ':' + e.v;
const entSplit = id => { const i = id.indexOf(':'); return {k:id.slice(0, i), v:id.slice(i + 1)}; };
const verdictOf = id => DB.verdicts[id] || '';
const primary = e => { const t = TYPES[e.type]; if(e.type === 'social' && e.fields.url){ const s = E.normSocial(e.fields.url); if(s) return s.v; } const v = (e.fields[t.fields[0][0]] || '').trim();
  /* a ship known only by its MMSI, an aircraft only by its address */ return v || (e.type === 'vessel' || e.type === 'aircraft' ? (e.fields[t.fields[1][0]] || '').trim() : ''); };
function entryKey(e){
  const t = TYPES[e.type]; if(!t) return null;
  if(e.type === 'location'){ const co = (e.fields.coordinates || '').trim(); return /-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?/.test(co) ? 'coords:' + E.norm('coords', co) : null; }
  if(e.type === 'social'){ const u = (e.fields.url || '').trim(), s = u && E.normSocial(u); if(s) return 'social:' + s.v; return null; }
  if(e.type === 'sshkey'){ const f = idSshFp(e); return f ? 'sshkey:' + f : null; }   /* a pasted public key alone is enough */
  if(!t.kind) return null;
  let v = primary(e); if(!v) return null;
  let k = t.kind;
  if(e.type === 'crypto') k = E.cryptoKind(v);
  /* a file entry holds whichever hash was known: name the kind by its length, so an MD5 or SHA-1 joins the same value found in records */
  if(e.type === 'file' && k === 'sha256'){ v = v.trim().toLowerCase(); k = v.length === 32 ? 'md5' : v.length === 40 ? 'sha1' : 'sha256'; }
  if(e.type === 'ip' && v.includes(':') && E.validIPv6(v.trim())) k = 'ipv6';
  if(e.type === 'daccount'){ const a = idAccount(v); if(!a) return null; k = a.k; v = a.v; }
  if(e.type === 'vessel' && !(e.fields.imo || '').trim()) k = 'mmsi';
  if(e.type === 'aircraft' && !(e.fields.registration || '').trim()) k = 'icao24';
  if(/^(vin|tail|icao24|imo|mmsi)$/.test(k)) v = E.norm(k, v);
  if(/^(phone|mac|pgp)$/.test(k)) v = E.norm(k, v);
  if(e.type === 'username') v = '@' + v.replace(/^@/, '');
  if(k === 'url') v = E.normUrl(v.trim()); else if(/^(ipv4|ipv6|domain|email|sha256|handle)$/.test(k)) v = v.toLowerCase();
  v = v.trim();
  if(k === 'cve') v = v.toUpperCase();
  return k + ':' + v;
}
/* before 1.76 every file entry was keyed sha256:, whatever the hash: move verdicts, watches and research notes to md5: / sha1: */
function migrateHashKeys(){ let n = 0;
  for(const store of [DB.verdicts, DB.verdictAt, DB.watch, DB.research]){ if(!store || typeof store !== 'object') continue;
    for(const key of Object.keys(store)){ const m = /^sha256:([0-9a-f]{32}|[0-9a-f]{40})$/i.exec(key); if(!m) continue;
      const nk = (m[1].length === 32 ? 'md5:' : 'sha1:') + m[1].toLowerCase(); if(!(nk in store)) store[nk] = store[key]; delete store[key]; n++; } }
  return n; }
/* Before 1.78 a URL was stored lowercased whole. Its case comes back from the record's own text, and verdicts, watches
   and notes saved under the old key move to the new one. A URL that cannot be found in its text (defanged, say) is
   left as it is and the record is marked so it is not searched again. Returns how many values or keys changed. */
function migrateUrlCase(){ let n = 0; const lc = new Map();
  for(const r of DB.records){ const U = (r.ents || []).filter(e => e.k === 'url'); if(!U.length) continue;
    if(!r.uc){ const text = [r.title, r.body, r.answer].filter(Boolean).join('\n'); let low = null;
      for(const e of U){ if(text.includes(e.v)) continue; if(low === null) low = text.toLowerCase(); if(low.length !== text.length) break;
        const i = low.indexOf(e.v); if(i < 0) continue; const v = E.normUrl(text.substr(i, e.v.length)); if(v !== e.v && v.toLowerCase() === e.v){ e.v = v; n++; } }
      if(low !== null) r.uc = 1; }
    for(const e of U) if(!lc.has('url:' + e.v.toLowerCase())) lc.set('url:' + e.v.toLowerCase(), 'url:' + e.v); }
  for(const e of DB.entries){ const k = e.type === 'url' ? entryKey(e) : null; if(k && !lc.has(k.toLowerCase())) lc.set(k.toLowerCase(), k); }
  for(const store of [DB.verdicts, DB.verdictAt, DB.watch, DB.research]){ if(!store || typeof store !== 'object') continue;
    for(const key of Object.keys(store)){ if(!key.startsWith('url:')) continue; const nk = lc.get(key.toLowerCase()); if(!nk || nk === key || key !== key.toLowerCase()) continue;
      if(!(nk in store)) store[nk] = store[key]; delete store[key]; n++; } }
  return n; }
/* what a typed account is: fediverse, Matrix, Nostr or an AT Protocol ID, by its shape */
function idAccount(v){ v = String(v || '').trim(); let m;
  if((m = /^@?([A-Za-z0-9_][A-Za-z0-9_.-]*)@((?:[a-z0-9-]+\.)+[a-z]{2,24})$/i.exec(v))) return {k:'fedi', v:('@' + m[1] + '@' + m[2]).toLowerCase()};
  if((m = /^@?([a-z0-9._=\/+-]+):((?:[a-z0-9-]+\.)+[a-z]{2,24}(?::\d{1,5})?)$/i.exec(v))) return {k:'matrix', v:('@' + m[1] + ':' + m[2]).toLowerCase()};
  if(/^npub1/i.test(v) && typeof IDKEYS !== 'undefined' && IDKEYS.npubHex(v)) return {k:'npub', v:v.toLowerCase()};
  if(/^nprofile1/i.test(v) && typeof IDKEYS !== 'undefined'){ const P = IDKEYS.nprofile(v); if(P) return {k:'npub', v:P.npub}; }
  if(/^[0-9a-f]{64}$/i.test(v) && typeof IDKEYS !== 'undefined') return {k:'npub', v:IDKEYS.hexNpub(v)};
  if(/^did:(plc:[a-z2-7]{24}|web:(?:[a-z0-9-]+\.)+[a-z]{2,24})$/i.test(v)) return {k:'did', v:v.toLowerCase()};
  return null; }
/* an SSH key entry by its fingerprint: from the public key when there is one, so it joins the key wherever it was seen */
function idSshFp(e){ const key = String(e.fields.key || '').trim(), m = /^(\S+)\s+(AAAA[A-Za-z0-9+/]+={0,3})/.exec(key), k = m && typeof IDKEYS !== 'undefined' ? IDKEYS.sshParse(m[2], m[1]) : null; if(k) return k.sha256;
  const f = String(e.fields.fingerprint || '').trim(); if(/^SHA256:[A-Za-z0-9+/]{43}$/.test(f)) return f; if(/^(?:MD5:)?(?:[0-9a-f]{2}:){15}[0-9a-f]{2}$/i.test(f)) return 'MD5:' + f.replace(/^MD5:/i, '').toLowerCase();
  if(/^[0-9a-f]{64}$/i.test(f) && typeof IDKEYS !== 'undefined') return IDKEYS.sshHexToFp(f); return null; }
const entryVerdict = e => { const k = entryKey(e); return k ? verdictOf(k) : (e.verdict || ''); };
function setEntryVerdict(e, v){ const k = entryKey(e); if(k){ if(v) DB.verdicts[k] = v; else delete DB.verdicts[k]; } else e.verdict = v; }
const sortRecs = l => l.slice().sort((a, b) => (a.ts && b.ts) ? a.ts - b.ts : a.ts ? -1 : b.ts ? 1 : a.addedAt - b.addedAt);

function derive(caseId){
  caseId = caseId || DB.active;
  if(cache[caseId]) return cache[caseId];
  const recs = sortRecs(DB.records.filter(r => r.caseId === caseId));
  const ents = new Map();
  for(const r of recs) for(const e of r.ents){ const id = entKey(e); if(!ents.has(id)) ents.set(id, {id, k:e.k, v:e.v, recs:[]}); ents.get(id).recs.push(r); }
  const entries = DB.entries.filter(e => e.caseId === caseId);
  const byKey = new Map(); for(const e of entries){ const k = entryKey(e); if(k) byKey.set(k, e); }
  const links = DB.links.filter(l => l.caseId === caseId);
  const c = theCase(caseId), t0r = c && c.t0 ? recById(c.t0) : null;
  return (cache[caseId] = {recs, ents, entries, byKey, links, t0:t0r && t0r.ts ? t0r.ts : null});
}
function globalEnts(){
  if(cache.__g) return cache.__g;
  const m = new Map();
  for(const r of DB.records) for(const e of r.ents){ const id = entKey(e); if(!m.has(id)) m.set(id, {id, k:e.k, v:e.v, recs:[], cases:new Set()}); const x = m.get(id); x.recs.push(r); x.cases.add(r.caseId); }
  for(const en of DB.entries){ const k = entryKey(en); if(!k) continue; if(!m.has(k)){ const s = entSplit(k); m.set(k, {id:k, k:s.k, v:s.v, recs:[], cases:new Set()}); } m.get(k).cases.add(en.caseId); }
  return (cache.__g = m);
}
/* how many records mention a vault entry */
function entryMentions(e){ const k = entryKey(e); if(!k) return []; const x = derive(e.caseId).ents.get(k); return x ? x.recs : []; }
function countBy(list, f){ const m = new Map(); for(const x of list){ const vs = f(x); for(const v of (Array.isArray(vs) ? vs : [vs])) if(v) m.set(v, (m.get(v) || 0) + 1); } return [...m.entries()].sort((a, b) => b[1] - a[1]); }

/* ---------- query ---------- */
function matchField(r, f){
  const v = f.val;
  switch(f.field){
    case 'host': return (r.host || '').toLowerCase().includes(v);
    case 'source': case 'from': return (r.source || '').toLowerCase().includes(v);
    case 'tag': return r.tags.some(t => t.toLowerCase().includes(v));
    case 'type': return r.type.startsWith(v);
    case 'kind': return r.ents.some(e => e.k === v);
    case 'ent': return r.ents.some(e => e.v.toLowerCase().includes(v));
    case 'verdict': return r.ents.some(e => verdictOf(entKey(e)) === v);
    case 'is': return v === 'open' ? (r.type === 'lead' && !r.answer) : r.type.startsWith(v);
    case 'fld': { const P = parseLog(r.body); if(P && (P.norm[f.name] != null || Object.keys(P.fields).some(k => k.toLowerCase() === f.name))) return fieldMatch(r, f.name, v);
      return (r.title + ' ' + r.body).toLowerCase().includes(f.text); }
  }
  return true;
}
function passes(r){
  if(UI.facet.host && r.host !== UI.facet.host) return false;
  if(UI.facet.type && r.type !== UI.facet.type) return false;
  if(UI.pivot && !r.ents.some(e => entKey(e) === UI.pivot)) return false;
  if(UI.facet.slot && !slotPass(r)) return false;
  if(UI.facet.win && !winPass(r)) return false;
  if(UI.facet.ids && !UI.facet.ids.includes(r.id)) return false;
  if(UI.ast){ const h = (r.title + ' ' + r.body + ' ' + r.host + ' ' + r.source + ' ' + r.tags.join(' ')).toLowerCase();
    if(!UI.ast.some(g => g.text.every(t => h.includes(t)) && g.neg.every(t => !h.includes(t)) && g.f.every(f => matchField(r, f) !== f.neg))) return false; }
  return true;
}

/* ---------- routing ---------- */
const AREAS = ['today','security','watch','trash','help','ctf','lab','home','cases','case','toolbox','entities','feeds','decoder','reference','settings','detections','playbooks','queries','notes','cloud','whatsnew','pad','notebook','certs','tradecraft','regex'];
const CASE_TABS = [['overview','Overview','layout-dashboard'],['vault','Vault','layers'],['entities','Entities','fingerprint'],['timeline','Timeline','clock'],['graph','Graph','waypoints'],['map','Places','map-pin'],['media','Media','images'],['infra','Infrastructure','network'],['questions','Analysis','scale'],['story','Story','newspaper'],['report','Report','file-chart-column']];
function parseHash(){
  const p = (location.hash || '#/home').replace(/^#\/?/, '').split('/').map(decodeURIComponent);
  if(p[0] === 'case' && DB.cases.some(c => c.id === p[1])){ DB.active = p[1]; return {area:'case', tab:CASE_TABS.some(t => t[0] === p[2]) ? p[2] : SHELL_HOME}; }
  if(p[0] === 'dorks') p[0] = 'queries';
  return {area:AREAS.includes(p[0]) && p[0] !== 'case' ? p[0] : 'home'};
}
/* how a case is called on screen: its name, up to the first “ — ” (“Op Lantern”). The TN-… code is kept as an
   internal reference — exports, search and “in TN-2026-014” still know it — but people read names, not numbers. */
const caseNm = (c, max = 48) => { if(typeof c === 'string') c = theCase(c); if(!c) return ''; const n = String(c.name || 'Untitled case').split(' — ')[0].trim() || String(c.name || 'Untitled case'); return n.length > max ? n.slice(0, max - 1).trimEnd() + '…' : n; };
/* the ▾ beside every “Save to <case>” button: pick which case it goes to (that case becomes the current one) */
const casePick = () => `<button type="button" class="btn ctpick" data-act="casePick" aria-haspopup="menu" aria-label="Choose the case to save to" title="Choose the case">${ico('chevron-down','sm')}</button>`;
const caseHash = (id, tab) => '#/case/' + encodeURIComponent(id || DB.active) + '/' + (tab || SHELL_HOME);
function go(h){ if(location.hash === h) onRoute(); else location.hash = h; }

async function hashRecords(){
  if(!(window.crypto && crypto.subtle)) return; const enc = new TextEncoder();
  for(const r of DB.records) if(!r.hash){ try{ const b = await crypto.subtle.digest('SHA-256', enc.encode(r.body || '')); r.hash = [...new Uint8Array(b)].map(x => x.toString(16).padStart(2,'0')).join(''); }catch(e){} }
}

/* ---------- toast ---------- */
let toastT = null;
function toast(msg, label, fn){
  const t = $('toast'); $('toastMsg').textContent = msg; const b = $('toastBtn'); b.hidden = !label;
  if(label){ b.textContent = label; b.onclick = () => { t.hidden = true; fn(); }; }
  t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, label ? 7000 : 2800);
}

/* ---------- shared render helpers ---------- */
const typeOfKind = k => TYPES[KIND_TO_TYPE[k]] || null;
function tbadge(typeId, cls = ''){ const t = TYPES[typeId] || {icon:'hash', color:'--t-file'}; return `<span class="tb ${cls}" style="--c:var(${t.color})">${ico(t.icon)}</span>`; }
function kindBadge(k, cls = ''){ const t = typeOfKind(k); return t ? tbadge(t.id, cls) : `<span class="tb ${cls}" style="--c:var(${/tx$/.test(k) ? '--t-finance' : k === 'pgp' ? '--t-identity' : k === 'session' || k === 'tox' || k === 'tgid' || k === 'dcid' ? '--t-contact' : '--t-file'})">${ico(/tx$/.test(k) ? 'arrow-right-left' : k === 'pgp' ? 'key-round' : k === 'session' || k === 'tox' || k === 'tgid' || k === 'dcid' ? 'message-square' : k === 'eventid' ? 'activity' : k === 'path' || k === 'file' ? 'file-code' : k === 'account' ? 'user' : 'hash')}</span>`; }
function entPill(id, opts = {}){
  const {k, v} = entSplit(id);
  return `<button class="ent${UI.sel && UI.sel.id === id ? ' on' : ''}" data-v="${verdictOf(id)}" data-act="selEnt" data-id="${esc(id)}" title="${esc(E.LABEL[k] || k)}">${kindBadge(k)}<span class="v">${esc(v)}</span>${opts.n ? `<span class="n">×${opts.n}</span>` : ''}</button>`;
}
function entryPill(e){
  return `<button class="ent" data-v="${entryVerdict(e)}" data-act="selEntry" data-id="${e.id}">${tbadge(e.type)}<span class="v"${MONO_TYPES.has(e.type) ? '' : ' style="font-family:var(--font);font-size:calc(13px * var(--ts,1))"'}>${esc(primary(e))}</span></button>`;
}
const vdLabel = v => { v = String(v || ''); return v ? `<span class="vd" data-v="${esc(v)}">${esc(v[0].toUpperCase() + v.slice(1))}</span>` : ''; };
const prioLabel = p => { p = String(p || 'medium'); return `<span class="prio" data-p="${esc(p)}">${esc(p[0].toUpperCase() + p.slice(1))}</span>`; };
const statusTag = s => `<span class="status" data-s="${esc(s)}">${esc({active:'Active', review:'In review', closed:'Archived'}[s] || s)}</span>`;
const conf = n => { n = [1, 2, 3].includes(+n) ? +n : 1; return `<span class="conf" data-c="${n}" title="Confidence: ${['','low','medium','high'][n]}"><i></i><i></i><i></i></span>`; };
const impl = i => `<span class="impl" data-i="${i}">${{real:'Working', mock:'Sample data', planned:'Planned'}[i]}</span>`;
const typeLabel = t => ({evidence:'Evidence', note:'Note', finding:'Finding', lead:'Question'}[t] || t);
const ILL_FOR = {waypoints:'graph', layers:'vault', 'folder-open':'vault', clock:'time', 'book-open':'time', filter:'search', search:'search', wrench:'tools', 'list-checks':'time'};
function empty(icon, title, body, acts){ const il = ILLUS[ILL_FOR[icon]]; return `<div class="empty" role="status">${il ? `<div class="illus">${il}</div>` : `<div class="art">${ico(icon)}</div>`}<h3>${title}</h3><div>${body}</div>${acts ? `<div class="acts">${acts}</div>` : ''}</div>`; }
/* spreadsheet formula injection: a text cell starting with = + - @ (or a tab/CR) is run as a formula by Excel and Sheets — prefix it with ' */
const csvFormula = v => typeof v === 'string' && /^[\s\u3000]*[=+\-@\t\r|\uFF1D\uFF0B\uFF0D\uFF20]/.test(v) ? "'" + v : v;
/* one CSV cell: text is made safe from spreadsheet formulas (numbers stay numbers), quoted only when it has to be (csvCell) or always (csvQ) */
const csvCell = v => { v = String(v == null ? '' : csvFormula(v)); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
const csvQ = v => '"' + String(v == null ? '' : csvFormula(v)).replace(/"/g, '""') + '"';
/* a file name that is safe on every system: no path parts, control or reserved characters, not too long */
function safeName(n, fb = 'download'){
  let s = String(n || '').normalize('NFC').replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, '').replace(/[\\/:*?"<>|]+/g, '_').replace(/^[\s.]+|[\s.]+$/g, '');
  if(/^(con|prn|aux|nul|com\d|lpt\d)(\.|$)/i.test(s)) s = '_' + s;
  if(s.length > 150){ const m = s.match(/(\.[a-z0-9]{1,8})$/i), ext = m ? m[1] : ''; s = s.slice(0, 150 - ext.length) + ext; }
  return s || fb;
}
function download(name, text, mime){
  name = safeName(name);
  try{ const u = URL.createObjectURL(new Blob([text], {type:mime || 'text/plain;charset=utf-8'})); const a = document.createElement('a'); a.href = u; a.download = name;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(u); a.remove(); }, 150); toast('Saved ' + name); }catch(e){ toast('The browser blocked the download'); }
}
const hostOf = u => { try{ return new URL(u).hostname.replace(/^www\./, ''); }catch(e){ return ''; } };
/* Standard page header: icon tile, title, subtitle, actions, and an optional KPI strip */
function pageHead(icon, color, title, sub, acts, kpis){
  return `<header class="phd"><div class="phd-t"><div class="phd-tt"><h1>${title}</h1>${sub ? `<p>${sub}</p>` : ''}</div>${acts ? `<div class="phd-a">${acts}</div>` : ''}</div>
    ${kpis && kpis.length ? `<div class="kpis">${kpis.map(([n, l, extra]) => `<div class="kpi"><b>${n}</b><span>${l}</span>${extra || ''}</div>`).join('')}</div>` : ''}</header>`;
}

/* pre-added tools: flag them, and add new ones from tools.json after an update — never re-add one the user deleted */
function ensureTools(){
  const gone = new Set(DB.deletedSeed || []), have = new Set(DB.tools.map(t => t.url)), seedUrls = new Set(TOOLS_SEED.map(t => t.url)); let n = 0;
  for(const t of DB.tools) if(t.seed === undefined) t.seed = seedUrls.has(t.url);
  for(const t of TOOLS_SEED) if(!have.has(t.url) && !gone.has(t.url)){ DB.tools.push({id:'t' + t.id + '-' + uid('u').slice(-4), name:t.name, url:t.url, cat:t.parentCategory, sub:t.childCategory, desc:t.description, tags:t.tags || [], pinned:false, starred:false, added:Date.now(), uses:0, seed:true}); n++; }
  return n;
}

/* Leaving with a change that is not on disk yet (big or encrypted workspaces write in the background): try once more,
   and if it still is not confirmed, let the browser ask "Leave site?" — the write finishes while the question is open. */
window.addEventListener('beforeunload', ev => {
  if(!DB || SEC.locked || !TABS.writer) return;
  if(isDirty()) flush();
  if(isDirty()){ ev.preventDefault(); ev.returnValue = ''; return ''; }
});
/* Decompress with a ceiling: a tiny "zip bomb" must not be able to fill memory. Throws when the output passes max bytes. */
const INFLATE_MAX = 256 * 1048576;
async function decompressCapped(bytes, kind, max = INFLATE_MAX){
  if(typeof DecompressionStream === 'undefined') throw new Error('This browser cannot decompress');
  const rd = new Blob([bytes]).stream().pipeThrough(new DecompressionStream(kind)).getReader(), parts = []; let n = 0;
  for(;;){ const {done, value} = await rd.read(); if(done) break; n += value.length;
    if(n > max){ try{ await rd.cancel(); }catch(e){} throw new Error('Decompressed data is larger than ' + Math.round(max / 1048576) + ' MB — stopped (possible decompression bomb)'); }
    parts.push(value); }
  const out = new Uint8Array(n); let o = 0; for(const p of parts){ out.set(p, o); o += p.length; } return out;
}

/* ---------- something broke: say so, and keep what is needed to fix it ----------
   An error in one view (the graph, say) can leave it unresponsive while the rest of the app works. The last 20 are kept in
   memory only — message, where in the code, the page and the last actions — never case data, and nothing is sent anywhere. */
const ERRS = [];
let errLastToast = 0;
function errNote(msg, where){
  const e = {at:new Date().toISOString(), msg:String(msg || 'Unknown error').slice(0, 400), where:String(where || '').split('\n').slice(0, 6).join('\n').slice(0, 1200),
    page:(typeof UI !== 'undefined' && UI.route) ? (UI.route.area + (UI.route.tab ? '/' + UI.route.tab : '')) : '', ver:typeof BRAND !== 'undefined' ? BRAND.version : '',
    did:(typeof DB !== 'undefined' && DB && Array.isArray(DB.log)) ? DB.log.slice(0, 4).map(x => x.what) : []};
  ERRS.unshift(e); ERRS.length = Math.min(ERRS.length, 20);
  if(Date.now() - errLastToast > 8000 && typeof toast === 'function'){ errLastToast = Date.now(); try{ toast('Something went wrong on this page', 'Copy details', () => copyText(ERRS.map(x => JSON.stringify(x, null, 1)).join('\n\n'), 'Details copied — paste them into your bug report')); }catch(x){} }
}
window.addEventListener('error', ev => { if(ev && ev.error === undefined && !ev.message) return; errNote(ev.message || (ev.error && ev.error.message), ev.error && ev.error.stack || (ev.filename ? ev.filename.split('/').pop() + ':' + ev.lineno : '')); });
window.addEventListener('unhandledrejection', ev => { const r = ev && ev.reason; if(r && (r.name === 'AbortError' || r.name === 'NotAllowedError')) return; errNote(r && r.message || String(r), r && r.stack); });
