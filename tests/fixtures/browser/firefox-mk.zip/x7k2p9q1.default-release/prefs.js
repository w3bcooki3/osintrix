// Mozilla User Preferences
user_pref("browser.download.dir", "C:\\Users\\mk\\Downloads");
user_pref("services.sync.username", "mk.trader@tuta.io");
