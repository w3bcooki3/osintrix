<?php
$smtp_host = "smtp.mail-relay.example.org"; $smtp_port = 587;
$smtp_user = "noreply@office-docs-share.example.org"; $smtp_pass = "Spring2024!";
// Telegram: @ScamaKing_support for updates
?>
